package agent

import (
	"context"
	"forevernine.com/midplat/base_libs/prom"
	"forevernine.com/midplat/base_libs/tos"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/base_server/ftrace"
	"forevernine.com/midplat/base_server/transport/fgrpc"
	"forevernine.com/midplat/base_server/transport/fhttp"
	"forevernine.com/midplat/base_server/transport/framework"
	"forevernine.com/midplat/scheduler/common/def"
	"forevernine.com/midplat/scheduler/srv/agent/internal/config"
	"forevernine.com/midplat/scheduler/srv/agent/internal/lifeline"
	"forevernine.com/midplat/scheduler/srv/agent/internal/service"
	"net"
	"strings"
)

func Run() (err error) {
	def.FlagParse()
	ctx := context.Background()

	if err = config.Init(); err != nil {
		panic(err)
	}
	//找端口
	l, err := tos.GetFreePorts(2)
	if err != nil {
		panic(err)
	}

	if err = lifeline.Run(ctx, l[0].Addr().String()); err != nil {
		panic(err)
	}

	gsrv := fgrpc.NewServer(def.ServerNameAgent, &config.AgeCfg, &config.AgeCfg.Net, fgrpc.Listener(l[0]))

	if err = service.Init(gsrv); err != nil {
		panic(err)
	}

	hsrv := fhttp.NewServer(def.ServerNameAgent, &config.AgeCfg, &config.AgeCfg.Net, fhttp.Listener(l[1]))

	ss := strings.Split(config.AgeCfg.GetPlatform(), "_")
	framework.InitRPCProm(ss[0], def.ServerNameAgent)
	ftrace.StartTracer(config.AgeCfg.GetPlatform(), def.ServerNameAgent, config.AgeCfg.GetTracerAddr(), def.Version)

	prom.InitPush(ctx, config.AgeCfg.PushGateway, def.InstanceName(l[1].Addr().(*net.TCPAddr).Port), def.ServerNameAgent, config.AgeCfg.Platform)

	//grpc server不去初始化服务发现，只使用中间件
	xlog.Infof(ctx, "[gRPC] server listening on: %s", gsrv.GetLis().Addr().String())
	go func() {
		if err = gsrv.Serve(gsrv.GetLis()); err != nil {
			panic(err)
		}
	}()

	if err = hsrv.Start(ctx); err != nil {
		panic(err)
	}

	return
}
