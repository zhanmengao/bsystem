package config

import (
	"context"
	"forevernine.com/midplat/base_libs/icfg/cfgtp"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/base_libs/xlog/logtyp"
	basicConfig "forevernine.com/midplat/base_server/config"
	"forevernine.com/midplat/scheduler/common/def"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"os"
	"sync"
)

type AgentConfig struct {
	cfgtp.BasicConfig
	Net               cfgtp.ListenConfig
	MasterAddr        string
	DaemonMs          int64
	DialFailCount     int64
	FirstDialSec      int64
	ServerDownloadURL string
}

func Init() (err error) {
	AgeCfg.MasterAddr = def.MasterAddr
	if def.RedirectIO {
		iopf, err := os.OpenFile(def.GetMonitPath(def.ServerNameAgent), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
		if err != nil {
			xlog.Errorf(context.Background(), "re stdio error = %s ", err)
			return err
		}
		os.Stdout = iopf
		os.Stderr = iopf

		if err = xlog.UseF9Log(AgeCfg.LogPath, def.ServerNameAgent, def.ServerNameAgent, AgeCfg.LogLevel); err != nil {
			return err
		}
	}
	return nil
}

var (
	lock sync.Mutex
)
var AgeCfg = AgentConfig{
	BasicConfig: cfgtp.BasicConfig{
		Platform:        "",
		LogLevel:        "",
		LogPath:         "/data/logs/servers",
		WorkerNum:       5000,
		InnerTimeout:    1000,
		TimeZone:        "",
		CoordinatorAddr: "",
		MonitorProcTime: false,
		Env:             "",
		K8s:             false,
		PushGateway:     "",
		FLogDAddr:       "",
		CompressType:    0,
		RPCTimeout:      100000,
		TracerAddr:      "",
	},
	Net: cfgtp.ListenConfig{
		GRPCPort: 23000,
		HTTPPort: 24000,
		TCPPort:  25000,
		UDPPort:  26000,
	},
}

func UpdateConfig(ctx context.Context, cfg *pb.AgentConfig) {
	lock.Lock()
	defer lock.Unlock()
	AgeCfg.Env = cfg.Env
	AgeCfg.TracerAddr = cfg.TraceAddr
	AgeCfg.DialFailCount = cfg.DialFailCount
	AgeCfg.DaemonMs = cfg.DaemonMs
	AgeCfg.FirstDialSec = cfg.FirstDialSec
	AgeCfg.PushGateway = cfg.PushAddr
	AgeCfg.ServerDownloadURL = cfg.ServerDownloadURL
	AgeCfg.LogLevel = cfg.LogLevel
	basicConfig.BasicConfig = &AgeCfg.BasicConfig
	xlog.SetLogLevel(logtyp.ParseLevel(AgeCfg.LogLevel))
}
