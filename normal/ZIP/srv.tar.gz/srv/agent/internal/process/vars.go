package process

import (
	"context"
	"fmt"
	"forevernine.com/midplat/base_libs/errors"
	"forevernine.com/midplat/base_libs/safego"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/base_proto/go/gerror"
	basepb "forevernine.com/midplat/base_proto/go/pb"
	"forevernine.com/midplat/base_server/httpcli"
	"forevernine.com/midplat/base_server/transport/framework"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"os"
	"sync"
	"time"
)

var (
	lock       sync.RWMutex
	processMap = make(map[int64]*ProInfo)
	sf         safego.SingleFlight
)

// AddProcess 添加实例
func AddProcess(platform, srvName string, info *pb.InstantInfo) (err error) {
	lock.Lock()
	defer lock.Unlock()

	err = addProcess(platform, srvName, info)
	return
}

func addProcess(platform, srvName string, info *pb.InstantInfo) (err error) {
	pro, err := os.FindProcess(int(info.PID))
	if err != nil {
		err = gerror.ErrDataNotFound().Format("pid %d not found ", info.PID)
		return
	}
	processMap[info.PID] = &ProInfo{
		Info:          info,
		Process:       pro,
		SrvName:       srvName,
		Platform:      platform,
		DialFailCount: 0,
	}
	return
}

func SetProcessStatus(ctx context.Context, pid int64, status pb.INSTANT_STATUS) (info *pb.InstantInfo, err error) {
	//先给进程发通知
	pro := GetProcess(pid)
	if pro == nil {
		err = gerror.ErrDataNotFound().Format("%d", pid)
		return
	}
	info = pro.Info
	rsp := &basepb.CustomErrorRsp{}
	_, err = httpcli.SendInnerReq(ctx, "midplat", "global", getStatusAddr(pro.Info.HTTPPort),
		framework.FormatJson, &basepb.OamSetStatusReq{
			Status: int32(status),
		}, rsp)
	if rsp.Head != nil && rsp.Head.Code > 0 {
		err = errors.NewError(int(rsp.Head.Code), rsp.Head.Msg).SetBasicErr(err)
	}
	if err != nil && status == pb.INSTANT_STATUS_STOP {
		//设置成功，修改进程状态
		pro.Info.Status = status
		if err = pro.Process.Kill(); err != nil {
			xlog.Warnf(ctx, "kill %s err = %s ", pro.Info, err)
		}
		err = nil
		return
	}
	if err != nil && status != pb.INSTANT_STATUS_STOP {
		return
	}
	//设置成功，修改进程状态
	pro.Info.Status = status
	if status == pb.INSTANT_STATUS_STOP {
		//10秒后去kill它
		go func() {
			time.Sleep(time.Second * 10)
			if err := pro.Process.Kill(); err != nil {
				xlog.Warnf(ctx, "kill %s err = %s ", pro.Info, err)
			}
		}()
	}
	return
}

func GetProcess(pid int64) *ProInfo {
	lock.RLock()
	defer lock.RUnlock()
	info, _ := processMap[pid]
	return info
}

func GetAllProcess() []*ProInfo {
	lock.RLock()
	defer lock.RUnlock()
	sli := make([]*ProInfo, 0, len(processMap))
	for _, p := range processMap {
		sli = append(sli, p)
	}
	return sli
}

func getStatusAddr(httpPort int64) string {
	return fmt.Sprintf("http://127.0.0.1:%d/oam/status/set", httpPort)
}

func DeleteProcess(pid int64) {
	lock.Lock()
	defer lock.Unlock()
	delete(processMap, pid)
}
