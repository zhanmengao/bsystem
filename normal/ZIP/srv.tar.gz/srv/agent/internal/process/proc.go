package process

import (
	"forevernine.com/midplat/base_libs/tos"
	"forevernine.com/midplat/scheduler/proto/go/pb"
)

func GetServiceList() (ret map[string]*pb.ServiceInfo) {
	ret = make(map[string]*pb.ServiceInfo)
	lock.RLock()
	defer lock.RUnlock()
	for _, ins := range processMap {
		srv, ok := ret[ins.SrvName]
		if !ok {
			srv = &pb.ServiceInfo{
				ServiceName: ins.SrvName,
				PodList:     map[uint64]*pb.PodInfo{},
			}
			ret[ins.SrvName] = srv
		}
		pod, ok := srv.PodList[ins.Info.PodID]
		if !ok {
			pod = &pb.PodInfo{
				ServiceName: ins.SrvName,
				PodID:       ins.Info.PodID,
				NodeName:    tos.GetHostName(),
				InstantList: []*pb.InstantInfo{},
			}
			srv.PodList[ins.Info.PodID] = pod
		}
		pod.InstantList = append(pod.InstantList, ins.Info)
	}
	return
}
