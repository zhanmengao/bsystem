package process

import (
	"context"
	"forevernine.com/midplat/base_proto/go/gerror"
	"forevernine.com/midplat/scheduler/srv/agent/internal/config"
	"forevernine.com/midplat/scheduler/srv/agent/internal/util"
	"io"
	"net/http"
	"os"
	"path"
)

func downloadServers(ctx context.Context, platform, version string, srvName ...string) (err error) {
	//下载
	downURL := util.GetCosURL(config.AgeCfg.ServerDownloadURL, platform, version)
	resp, err := http.Get(util.GetCosURL(downURL, platform, version))
	if err != nil {
		err = gerror.ErrServerNetwork().Format(downURL).SetBasicErr(err)
		return
	}
	defer func() {
		_ = resp.Body.Close()
	}()
	//打开本地文件
	srvZipPath := path.Join(os.TempDir(), "servers", platform, version+".tar.gz")
	_ = os.MkdirAll(srvZipPath, 0755)
	pf, err := os.OpenFile(srvZipPath, os.O_WRONLY|os.O_CREATE, 0644)
	if err != nil {
		err = gerror.ErrServerInternalUnknown().Format(srvZipPath).SetBasicErr(err)
		return
	}
	defer func() {
		_ = pf.Close()
		_ = os.Remove(srvZipPath)
	}()
	_, err = io.Copy(pf, resp.Body)
	if err != nil {
		err = gerror.ErrServerInternalUnknown().Format("io copy").SetBasicErr(err)
		return
	}
	_, err = pf.Seek(0, io.SeekStart)
	if err != nil {
		err = gerror.ErrServerInternalUnknown().Format("seek").SetBasicErr(err)
		return
	}
	//解压缩

	return
}
