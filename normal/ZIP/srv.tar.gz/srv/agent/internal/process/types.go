package process

import (
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"os"
)

type ProInfo struct {
	Info          *pb.InstantInfo
	Process       *os.Process
	Platform      string
	SrvName       string
	DialFailCount int64
}
