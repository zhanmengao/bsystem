package process

import (
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"testing"
)

func TestFork(t *testing.T) {
	if pro, err := fork("fimsrv", "/data/servers/bin/fimsrv_1.1", "-c /data/configcenter/midplat/midplat_sv/midplat.yaml",
		9995, 9996, 9997, pb.INSTANT_STATUS_ENABLE); err != nil {
		t.Fatal(err)
	} else {
		t.Log(pro.Pid)
		status, err := pro.Wait()
		if err != nil {
			t.Fatal(err)
		}
		t.Log(status.String())
	}

}
