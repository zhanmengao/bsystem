package process

import (
	"context"
	"fmt"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/base_libs/xtime"
	"forevernine.com/midplat/base_proto/go/gerror"
	"forevernine.com/midplat/base_server/ftrace"
	"forevernine.com/midplat/base_server/transport/framework"
	"forevernine.com/midplat/scheduler/common/def"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/agent/internal/util"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"syscall"
)

func Fork(ctx context.Context, platform, srvName, version string, command string, podID uint64,
	httpPort, grpcPort, frpcPort int64, status pb.INSTANT_STATUS) (pro *ProInfo, bCreate bool, err error) {
	pro = &ProInfo{
		Platform: platform,
		SrvName:  srvName,
	}
	if root := framework.GetBaseSpan(ctx); root.IsValid() {
		_, sp := ftrace.NewSpan(ctx, "internal", "fork")
		defer func() {
			sp.SetAttributes("process", pro.Info)
			if err != nil {
				sp.SetError(err)
			}
			sp.SetAttributes("platform", platform)
			sp.SetAttributes("server", srvName)
			sp.SetAttributes("bin", util.GetServerBinPath(srvName, version))
			sp.SetAttributes("version", version)
			sp.SetAttributes("pod", podID)
			sp.End()
		}()
	}
	lock.Lock()
	defer lock.Unlock()
	//如果该进程已存在，则直接return信息
	for _, p := range processMap {
		if p.Info.PodID == podID && p.Info.Version == version {
			pro = p
			return
		}
	}

	//TODO 先去下载
	if !util.IsServerBinExist(srvName, version) {

	}

	//此时文件已存在
	if pro.Process, err = fork(srvName, util.GetServerBinPath(srvName, version), command, httpPort, grpcPort, frpcPort, status); err != nil {
		return
	}
	pro.Info = &pb.InstantInfo{
		Status:   status,
		HTTPPort: httpPort,
		FRPCPort: frpcPort,
		GRPCPort: grpcPort,
		PID:      int64(pro.Process.Pid),
		Version:  version,
		PodID:    podID,
		Command:  command,
		CreateAt: xtime.Unix(),
	}
	if err = addProcess(platform, srvName, pro.Info); err != nil {
		return
	}
	bCreate = true
	return
}

func fork(srvName, binPath, command string, httpPort, grpcPort, frpcPort int64, status pb.INSTANT_STATUS) (pro *os.Process, err error) {
	ss := strings.Split(command, " ")
	if httpPort > 0 {
		ss = append(ss, "-http")
		ss = append(ss, strconv.Itoa(int(httpPort)))
	}
	ss = append(ss, "-grpc")
	ss = append(ss, strconv.Itoa(int(grpcPort)))
	ss = append(ss, "-frpc")
	ss = append(ss, strconv.Itoa(int(frpcPort)))
	cmd := exec.Command(binPath, ss...)
	pf, err := os.OpenFile(def.GetMonitPath(srvName), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer pf.Close()
	cmd.Stdout = pf
	cmd.Stderr = pf
	cmd.SysProcAttr = &syscall.SysProcAttr{
		Setsid: true,
	}
	//添加启动状态到env
	cmd.Env = append(cmd.Env, fmt.Sprintf("status=%d", status))
	if err = cmd.Start(); err != nil {
		err = gerror.ErrServerInternalUnknown().SetBasicErr(err)
		return
	}
	go func() {
		exitCode, err2 := cmd.Process.Wait()
		if err != nil {
			xlog.Warnf(context.Background(), "waitpid [%d] error = %s ", cmd.Process.Pid, err2)
		} else {
			xlog.Warnf(context.Background(), "[%d] exit = [%s]", cmd.Process.Pid, exitCode.String())
		}
	}()
	pro = cmd.Process
	return
}
