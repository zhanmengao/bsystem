package service

import (
	"forevernine.com/midplat/base_server/transport/fgrpc"
	"forevernine.com/midplat/scheduler/proto/go/pb"
)

func Init(gSrv *fgrpc.Server) (err error) {
	srv := &service{}
	pb.RegisterAgentServer(gSrv, srv)
	return
}
