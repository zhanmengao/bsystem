package service

import (
	"context"
	"forevernine.com/midplat/base_libs/xlog"
	basepb "forevernine.com/midplat/base_proto/go/pb"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/agent/internal/global"
	"forevernine.com/midplat/scheduler/srv/agent/internal/lifeline"
	"forevernine.com/midplat/scheduler/srv/agent/internal/process"
	"os"
	"time"
)

type service struct {
}

func (s service) Ping(ctx context.Context, req *pb.PingReq) (rsp *pb.PingRsp, err error) {
	rsp = &pb.PingRsp{}
	return
}

func (s service) AgentDown(ctx context.Context, req *pb.AgentDownReq) (rsp *pb.AgentDownRsp, err error) {
	rsp = &pb.AgentDownRsp{Head: &basepb.RspHead{}}
	//结束掉自己的所有进程
	lifeline.OnDown()
	for _, p := range process.GetAllProcess() {
		if err = p.Process.Kill(); err != nil {
			xlog.Errorf(ctx, "kill %s error = %s ", p.Info, err)
		}
		err = nil
	}
	rsp.Info = global.BuildNode()
	go func() {
		time.Sleep(time.Duration(3) * time.Second)
		os.Exit(0)
	}()
	return
}
