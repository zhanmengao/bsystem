package service

import (
	"context"
	"forevernine.com/midplat/base_libs/tos"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/agent/internal/config"
	"forevernine.com/midplat/scheduler/srv/agent/internal/process"
	"net"
)

func (s service) CreateInstant(ctx context.Context, req *pb.CreateInstantReq) (rsp *pb.CreateInstantRsp, err error) {
	rsp = &pb.CreateInstantRsp{}

	//获取端口
	ports, err := tos.GetFreePorts(3)
	if err != nil {
		return
	}
	httpPort := int64(ports[0].Addr().(*net.TCPAddr).Port)
	grpcPort := int64(ports[1].Addr().(*net.TCPAddr).Port)
	frpcPort := int64(ports[2].Addr().(*net.TCPAddr).Port)
	if req.HttpPort > 0 {
		httpPort = req.HttpPort
	}

	for _, port := range ports {
		port.Close()
	}
	pro, _, err := process.Fork(ctx, config.AgeCfg.Platform, req.Service, req.Version, req.Command, req.PodID, httpPort, grpcPort, frpcPort, req.Status)
	if err != nil {
		return
	}
	rsp.Info = pro.Info
	return
}

func (s service) SetInstantStatus(ctx context.Context, req *pb.SetInstantStatusReq) (rsp *pb.SetInstantStatusRsp, err error) {
	rsp = &pb.SetInstantStatusRsp{}
	//设置进程状态
	for _, pid := range req.Pid {
		var info *pb.InstantInfo
		if info, err = process.SetProcessStatus(ctx, pid, req.Status); err != nil {
			xlog.Errorf(ctx, "Set pid[%d] = [%d] .error = %s ", pid, req.Status)
			return
		}
		rsp.InstantList = append(rsp.InstantList, info)
	}

	return
}
