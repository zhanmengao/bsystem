package service

import (
	"context"
	"forevernine.com/midplat/base_proto/go/gerror"
	basepb "forevernine.com/midplat/base_proto/go/pb"
	"forevernine.com/midplat/scheduler/common/def"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/agent/internal/config"
	"forevernine.com/midplat/scheduler/srv/agent/internal/lifeline"
	"forevernine.com/midplat/scheduler/srv/agent/internal/util"
	"io"
	"os"
)

func (s service) AgentUpdate(ctx context.Context, req *pb.AgentUpdateReq) (rsp *basepb.CustomErrorRsp, err error) {
	rsp = &basepb.CustomErrorRsp{Head: &basepb.RspHead{}}
	if def.Version == req.Version {
		return
	}
	binPath := util.GetServerBinPath(def.ServerNameAgent, req.Version)
	//TODO 去拉自己的二进制
	if !util.IsServerBinExist(def.ServerNameAgent, req.Version) {

	}
	rpf, err := os.Open(binPath)
	if err != nil {
		err = gerror.ErrServerInternalUnknown().Format("open %s error", binPath).SetBasicErr(err)
		return
	}
	defer rpf.Close()
	//rm再cp
	if err = os.Remove(def.AgentSystemdPath); err != nil {
		err = gerror.ErrServerInternalUnknown().Format("remove %s error", def.AgentSystemdPath).SetBasicErr(err)
		return
	}
	var wpf *os.File
	if wpf, err = os.Create(def.AgentSystemdPath); err != nil {
		err = gerror.ErrServerInternalUnknown().Format("open %s error", def.AgentSystemdPath).SetBasicErr(err)
		return
	}
	defer wpf.Close()
	//cp
	if _, err = io.Copy(wpf, rpf); err != nil {
		err = gerror.ErrServerInternalUnknown().Format("copy %s to %s error", binPath, def.AgentSystemdPath).SetBasicErr(err)
		return
	}
	//授权
	if err = os.Chmod(def.AgentSystemdPath, 0755); err != nil {
		err = gerror.ErrServerInternalUnknown().SetBasicErr(err)
		return
	}
	//直接退出，等待systemd拉起
	lifeline.OnLogout()
	os.Exit(0)
	return
}

func (s service) ConfigUpdate(ctx context.Context, req *pb.ConfigChangedReq) (rsp *basepb.CustomErrorRsp, err error) {
	rsp = &basepb.CustomErrorRsp{Head: &basepb.RspHead{}}
	config.UpdateConfig(ctx, req.Config)
	return
}
