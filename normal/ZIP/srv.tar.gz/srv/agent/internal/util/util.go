package util

import (
	"errors"
	"fmt"
	"os"
)

func IsServerBinExist(srvName, version string) bool {
	binPath := GetServerBinPath(srvName, version)
	_, err := os.Stat(binPath)
	if errors.Is(err, os.ErrNotExist) {
		return false
	}
	return true
}

func GetServerBinPath(srvName, version string) string {
	return fmt.Sprintf("/data/servers/bin/%s_%s", srvName, version)
}

func GetCosURL(downloadURL, platform, version string) string {
	return fmt.Sprintf(downloadURL, platform, platform, version)
}
