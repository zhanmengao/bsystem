package global

import (
	"forevernine.com/midplat/base_libs/tos"
	"forevernine.com/midplat/scheduler/common/def"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/agent/internal/config"
	"forevernine.com/midplat/scheduler/srv/agent/internal/process"
	"os"
)

var (
	Status        pb.AGENT_STATUS
	AgentGrpcAddr string
)

func BuildNode() *pb.NodeInfo {
	return &pb.NodeInfo{
		Platform:     config.AgeCfg.Platform,
		AgentPID:     int64(os.Getpid()),
		AgentVersion: def.Version,
		GRPCAddr:     AgentGrpcAddr,
		NodeName:     tos.GetHostName(),
		ServiceList:  process.GetServiceList(),
	}
}
