package lifeline

import (
	"context"
	"forevernine.com/midplat/base_libs/tos"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/scheduler/common/def"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/agent/internal/config"
	"forevernine.com/midplat/scheduler/srv/agent/internal/global"
	"forevernine.com/midplat/scheduler/srv/agent/internal/process"
	"os"
	"time"
)

func OnLogout() {
	global.Status = pb.AGENT_STATUS_OFFLINE
	ctx := context.Background()
	req := &pb.AgentLogoutReq{
		Info: &pb.NodeInfo{
			Platform:     config.AgeCfg.Platform,
			AgentPID:     int64(os.Getpid()),
			AgentVersion: def.Version,
			GRPCAddr:     global.AgentGrpcAddr,
			NodeName:     tos.GetHostName(),
			ServiceList:  process.GetServiceList(),
		},
	}

	masterCli, err := pb.NewMasterAgentFGrpcConn(ctx, config.AgeCfg.MasterAddr, time.Duration(3)*time.Second)
	if err != nil {
		xlog.Errorf(ctx, "connect to %s error = %s ", config.AgeCfg.MasterAddr, err.Error())
		return
	}
	_, err = masterCli.AgentLogout(ctx, req, "")
	if err != nil {
		xlog.Errorf(ctx, "logout error = %s ", err)
		return
	}
}
