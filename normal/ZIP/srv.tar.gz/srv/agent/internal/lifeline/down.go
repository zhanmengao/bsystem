package lifeline

import (
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/agent/internal/global"
)

func OnDown() {
	global.Status = pb.AGENT_STATUS_DOWN
}
