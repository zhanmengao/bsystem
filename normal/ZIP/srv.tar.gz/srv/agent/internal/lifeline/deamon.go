package lifeline

import (
	"context"
	"fmt"
	"forevernine.com/midplat/base_libs/tos"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/base_libs/xtime"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/agent/internal/config"
	"forevernine.com/midplat/scheduler/srv/agent/internal/global"
	"forevernine.com/midplat/scheduler/srv/agent/internal/process"
	"net"
	"os"
	"time"
)

//守护所有进程
func daemonProcess() {
	sigCh := make(chan os.Signal, 5)
	//signal.Notify(sigCh, syscall.SIGCHLD)
	tm := time.NewTimer(time.Duration(config.AgeCfg.DaemonMs) * time.Millisecond)
	for {
		ctx := context.Background()
		select {
		case sig := <-sigCh:
			xlog.Infof(ctx, "rcv sig %s ", sig)
			watchAllProcess(ctx)
		case <-tm.C:
			watchAllProcess(ctx)
		}
		tm.Reset(time.Duration(config.AgeCfg.DaemonMs) * time.Millisecond)
	}

}

//扫描一次所有进程
func watchAllProcess(ctx context.Context) {
	pl := process.GetAllProcess()
	//探测
	for _, p := range pl {
		if p.Info.CreateAt >= xtime.Unix()-int64(config.AgeCfg.FirstDialSec) {
			continue
		}
		func() {
			conn, err := net.Dial("tcp", fmt.Sprintf("127.0.0.1:%d", p.Info.HTTPPort))
			if err != nil {
				//++
				p.DialFailCount++
				if p.DialFailCount >= int64(config.AgeCfg.DialFailCount) {
					//连不上，说明出问题了，抛事件
					if p.Process != nil {
						_ = p.Process.Kill()
					}
					onProcessDump(ctx, p)
				}
			} else {
				p.DialFailCount = 0
			}
			if conn != nil {
				defer conn.Close()
			}
		}()
	}
}

func onProcessDump(ctx context.Context, info *process.ProInfo) {
	//被STOP的进程结束了，不管他
	defer func() {
		//删除进程
		process.DeleteProcess(info.Info.PID)
	}()
	xlog.Errorf(ctx, "srv %s dump event.", info)
	//先通知关闭事件
	NotifyDumpToMaster(ctx, &pb.InstantDumpReq{
		Platform: info.Platform,
		NodeName: tos.GetHostName(),
		Pid:      info.Info.PID,
	})
	if info.Info.Status == pb.INSTANT_STATUS_STOP {
		return
	}
	//不在线的时候不处理任何事件
	if global.Status != pb.AGENT_STATUS_ONLINE {
		return
	}

	go func() {
		for {
			//给新端口
			var httpPort = info.Info.HTTPPort
			var grpcPort = info.Info.GRPCPort
			var frpcPort = info.Info.FRPCPort
			ports, err := tos.GetFreePorts(3)
			if err == nil {
				//如果使用我们选择的端口
				if httpPort > 0 {
					httpPort = int64(ports[0].Addr().(*net.TCPAddr).Port)
				}
				grpcPort = int64(ports[1].Addr().(*net.TCPAddr).Port)
				frpcPort = int64(ports[2].Addr().(*net.TCPAddr).Port)
			}
			for _, port := range ports {
				port.Close()
			}
			//重启进程
			pro, bCreate, err := process.Fork(ctx, info.Platform, info.SrvName, info.Info.Version, info.Info.Command,
				info.Info.PodID, httpPort, grpcPort, frpcPort, info.Info.Status)

			//重启进程失败，告出来
			if err != nil {
				xlog.Fatalf(ctx, "restart %s error = %s ", info.Info, err)
				time.Sleep(time.Second)
				continue
			}
			if bCreate {
				//通知master，通知不成功就把事件缓存下来，用心跳包通知
				NotifyRestartToMaster(ctx, &pb.InstantRestartReq{
					Platform:    info.Platform,
					NodeName:    tos.GetHostName(),
					Info:        pro.Info,
					ServiceName: info.SrvName,
				})
			}
			break
		}
	}()
}
