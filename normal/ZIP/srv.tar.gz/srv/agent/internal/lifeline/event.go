package lifeline

import (
	"context"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/agent/internal/config"
	uuid "github.com/satori/go.uuid"
	"sync"
	"time"
)

var (
	reqListLock        sync.Mutex
	processRestartList = make(map[string]*pb.InstantRestartReq, 5)
	processDumpList    = make(map[string]*pb.InstantDumpReq, 5)
)

// NotifyDumpToMaster 事件缓存下来
func NotifyDumpToMaster(ctx context.Context, req *pb.InstantDumpReq) {
	var err error
	defer func() {
		if err != nil {
			pushDumpEvent(req)
		}
	}()
	masterCli, err := pb.NewMasterAgentFGrpcConn(ctx, config.AgeCfg.MasterAddr, time.Duration(3)*time.Second)
	if err != nil {
		xlog.Errorf(ctx, "connect to %s error = %s ", config.AgeCfg.MasterAddr, err.Error())
		return
	}
	_, err = masterCli.InstantDump(ctx, req, "")
}

func NotifyRestartToMaster(ctx context.Context, req *pb.InstantRestartReq) {
	var err error
	defer func() {
		if err != nil {
			pushRestartEvent(req)
		}
	}()
	masterCli, err := pb.NewMasterAgentFGrpcConn(ctx, config.AgeCfg.MasterAddr, time.Duration(3)*time.Second)
	if err != nil {
		xlog.Errorf(ctx, "connect to %s error = %s ", config.AgeCfg.MasterAddr, err.Error())
		return
	}
	_, err = masterCli.InstantRestart(ctx, req, "")
}

func pushDumpEvent(req *pb.InstantDumpReq) {
	reqListLock.Lock()
	defer reqListLock.Unlock()
	processDumpList[uuid.NewV5(uuid.NewV4(), "req").String()] = req
}
func pushRestartEvent(req *pb.InstantRestartReq) {
	reqListLock.Lock()
	defer reqListLock.Unlock()
	processRestartList[uuid.NewV5(uuid.NewV4(), "req").String()] = req
}
