package lifeline

import (
	"context"
	"forevernine.com/midplat/base_libs/oam"
	"forevernine.com/midplat/base_libs/tos"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/scheduler/common/def"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/agent/internal/config"
	"forevernine.com/midplat/scheduler/srv/agent/internal/global"
	"forevernine.com/midplat/scheduler/srv/agent/internal/process"
	"os"
	"syscall"
	"time"
)

func Run(ctx context.Context, grpcAddr string) (err error) {
	//先Login
	global.AgentGrpcAddr = grpcAddr
	var loginTm = time.Second
	var rsp *pb.AgentLoginRsp
	for {
		var masterCli pb.IMasterAgentFGrpcConn
		if masterCli, err = pb.NewMasterAgentFGrpcConn(ctx, config.AgeCfg.MasterAddr, time.Duration(3)*time.Second); err != nil {
			return
		}
		//登录失败则不断重试，直到登录成功
		rsp, err = masterCli.AgentLogin(ctx, &pb.AgentLoginReq{
			NodeName:     tos.GetHostName(),
			GRPCAddr:     grpcAddr,
			AgentVersion: def.Version,
			AgentPID:     int64(os.Getpid()),
		}, "")
		if err != nil {
			xlog.Fatalf(ctx, "login to master : [%s]  error = %s ", config.AgeCfg.MasterAddr, err)
			time.Sleep(loginTm)
		} else {
			break
		}
	}
	global.AgentGrpcAddr = rsp.Info.GRPCAddr
	config.AgeCfg.Platform = rsp.Info.Platform
	config.UpdateConfig(ctx, rsp.Config)
	//根据Rsp构造Map
	for _, srv := range rsp.Info.ServiceList {
		for _, pod := range srv.PodList {
			for _, ins := range pod.InstantList {
				if err = process.AddProcess(config.AgeCfg.Platform, srv.ServiceName, ins); err != nil {
					//Pid Not Found : restart
					xlog.Errorf(ctx, "fail to find %s . err  = %s.will send dump ", ins, err)
					onProcessDump(ctx, &process.ProInfo{
						Info:     ins,
						Platform: config.AgeCfg.Platform,
						SrvName:  srv.ServiceName,
					})
					err = nil
				}
			}
		}
	}
	if err = oam.SetSignalHandle(func(signal os.Signal) {
		OnLogout()
		os.Exit(0)
	}, syscall.SIGHUP, syscall.SIGKILL); err != nil {
		return
	}
	global.Status = pb.AGENT_STATUS_ONLINE
	//进入心跳和守护循环
	go daemonProcess()
	go heartbeat()
	return
}
