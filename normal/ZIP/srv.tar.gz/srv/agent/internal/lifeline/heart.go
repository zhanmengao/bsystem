package lifeline

import (
	"context"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/agent/internal/config"
	"forevernine.com/midplat/scheduler/srv/agent/internal/global"
	"time"
)

func heartbeat() {
	//心跳
	for {
		time.Sleep(time.Duration(5) * time.Second)
		if global.Status != pb.AGENT_STATUS_ONLINE {
			return
		}
		ctx := context.Background()
		masterCli, err := pb.NewMasterAgentFGrpcConn(ctx, config.AgeCfg.MasterAddr, time.Duration(3)*time.Second)
		if err != nil {
			xlog.Errorf(ctx, "connect to %s error = %s ", config.AgeCfg.MasterAddr, err.Error())
			continue
		}
		_, err = masterCli.AgentHeart(ctx, &pb.AgentHeartBeatReq{
			Info: global.BuildNode(),
		}, "")
		if err != nil {
			xlog.Errorf(ctx, "heart to %s error = %s ", config.AgeCfg.MasterAddr, err.Error())
			continue
		}
		//事件
		srvCli, err := pb.NewMasterAgentFGrpcConn(ctx, config.AgeCfg.MasterAddr, time.Duration(3)*time.Second)
		if err != nil {
			xlog.Errorf(ctx, "heart to %s error = %s ", config.AgeCfg.MasterAddr, err.Error())
			continue
		}
		func() {
			reqListLock.Lock()
			defer reqListLock.Unlock()
			for reqID, req := range processDumpList {
				_, err = srvCli.InstantDump(ctx, req, "")
				delete(processDumpList, reqID)
			}
			for reqID, req := range processRestartList {
				_, err = srvCli.InstantRestart(ctx, req, "")
				delete(processRestartList, reqID)
			}
		}()

	}
}
