package service

import (
	"context"
	basepb "forevernine.com/midplat/base_proto/go/pb"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/master/internal/store"
)

// InstantDump 服务挂了
func (s *service) InstantDump(ctx context.Context, req *pb.InstantDumpReq) (rsp *basepb.CustomErrorRsp, err error) {
	rsp = &basepb.CustomErrorRsp{Head: &basepb.RspHead{}}
	if err = store.UpdateInstantStatus(ctx, req.Platform, req.NodeName, pb.INSTANT_STATUS_STOP, []int64{req.Pid}); err != nil {
		return
	}
	return
}

func (s *service) InstantRestart(ctx context.Context, req *pb.InstantRestartReq) (rsp *basepb.CustomErrorRsp, err error) {
	rsp = &basepb.CustomErrorRsp{Head: &basepb.RspHead{}}
	if err = store.AddInstant(ctx, req.Platform, req.NodeName, req.ServiceName, req.Info); err != nil {
		return
	}
	return
}
