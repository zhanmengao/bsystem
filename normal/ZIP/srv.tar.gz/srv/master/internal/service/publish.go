package service

import (
	"context"
	"forevernine.com/midplat/base_proto/go/gerror"
	basepb "forevernine.com/midplat/base_proto/go/pb"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/master/internal/agent"
	"forevernine.com/midplat/scheduler/srv/master/internal/config"
	"forevernine.com/midplat/scheduler/srv/master/internal/store"
)

// DeployService 部署
func (s *service) DeployService(ctx context.Context, req *pb.DeployServiceReq) (rsp *pb.DeployServiceRsp, err error) {
	rsp = &pb.DeployServiceRsp{Head: &basepb.RspHead{}}
	status := config.GetOpenStatus()
	//读srv信息
	srvNameList := make([]string, 0, 10)
	for _, srv := range req.ServiceInfo {
		srvNameList = append(srvNameList, srv.ServiceName)
		var srvInfo *pb.ServiceInfo
		if srvInfo, err = store.GetService(ctx, req.Platform, srv.ServiceName); err != nil {
			return
		}
		var agentList []*pb.NodeInfo
		//先做一次check，再部署
		for _, pod := range srvInfo.PodList {
			if len(pod.InstantList) > 1 {
				err = gerror.ErrServerBadParam().Format("srv %s deploy now ", srvInfo.ServiceName)
				return
			}
			agentList, err = agent.GetAndCheckAgent(ctx, req.Platform, []string{pod.NodeName})
			if err != nil {
				return
			}
			//不填命令的情况，使用旧有命令
			if srv.Command == "" {
				srv.Command = pod.Command
			}
		}
		//遍历pod
		oldVersion := ""
		podIDList := make([]uint64, 0, 10)
		for _, pod := range srvInfo.PodList {
			if pod.Status != pb.POD_STATUS_RUNNING {
				continue
			}
			podIDList = append(podIDList, pod.PodID)
			oldVersion = pod.Version
			//找机器
			for _, node := range agentList {
				if node.NodeName == pod.NodeName {
					//开始部署服务
					port := pod.HttpPort
					switch srv.CustomHttp {
					case pb.MOD_PORT_SELECT_CUSTOM:
						port = srv.HttpPort
					case pb.MOD_PORT_SELECT_RANDOM:
						port = 0
					}
					if err = agent.Deploy(ctx, req.Platform, req.Version, srv.ServiceName, srv.Command, pod.PodID, node, status, port); err != nil {
						return
					}
					break
				}
			}
		}
		//如果是直接重启，则启动后立刻关停其他服务
		if status == pb.INSTANT_STATUS_ENABLE {
			if _, err = agent.SetInstantStatus(ctx, req.Platform, podIDList, oldVersion, pb.INSTANT_STATUS_STOP); err != nil {
				return
			}
		}
	}
	if status == pb.INSTANT_STATUS_ENABLE {
		//pod info
		if err = store.UpdatePodVersion(ctx, req.Platform, req.Version, srvNameList...); err != nil {
			return
		}
	}
	srvRsp, err := s.GetServiceList(ctx, &pb.GetServiceInfoReq{Platform: req.Platform})
	if err != nil {
		return
	}
	rsp.Info = srvRsp.ServiceList
	return
}

// SetPodStatus 设置pod状态
func (s *service) SetPodStatus(ctx context.Context, req *pb.SetPodStatusReq) (rsp *pb.SetPodStatusRsp, err error) {
	rsp = &pb.SetPodStatusRsp{Head: &basepb.RspHead{}}
	var podList []*pb.PodInfo
	if podList, err = agent.SetInstantStatus(ctx, req.Platform, []uint64{req.PodID}, req.Version, req.Status); err != nil {
		return
	}
	rsp.Info = podList[0]
	return
}

// PublishService 服务正式发布，STOP掉所有版本不一致的Instant
func (s *service) PublishService(ctx context.Context, req *pb.PublishServiceReq) (rsp *pb.PublishServiceRsp, err error) {
	rsp = &pb.PublishServiceRsp{Head: &basepb.RspHead{}}
	if err = agent.SetVersionEnable(ctx, req.Platform, req.ServiceName, req.Version); err != nil {
		return
	}
	//pod info
	if err = store.UpdatePodVersion(ctx, req.Platform, req.Version, req.ServiceName...); err != nil {
		return
	}
	for _, srv := range req.ServiceName {
		var info *pb.ServiceInfo
		info, err = store.GetService(ctx, req.Platform, srv)
		if err != nil {
			return
		}
		rsp.Info = append(rsp.Info, info)
	}

	return
}
