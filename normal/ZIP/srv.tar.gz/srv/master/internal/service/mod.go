package service

import (
	"context"
	basepb "forevernine.com/midplat/base_proto/go/pb"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/master/internal/store"
	"forevernine.com/midplat/scheduler/srv/master/internal/util"
)

// CreateService 创建service
func (s *service) CreateService(ctx context.Context, req *pb.CreateServiceReq) (rsp *pb.CreateServiceRsp, err error) {
	rsp = &pb.CreateServiceRsp{Head: &basepb.RspHead{}}
	m := make(map[uint64]string, len(req.NodeName))
	for _, nodeName := range req.NodeName {
		//遍历机器列表，开始部署，写入pod
		var podID uint64
		if podID, err = util.GenPodID(); err != nil {
			return
		}
		m[podID] = nodeName
	}
	if rsp.Info, err = store.CreateService(ctx, req.Platform, req.ServiceName, req.Version, req.Command, m, req.HttpPort); err != nil {
		return
	}
	return
}

// ModifyService 修改服务部署情况
func (s *service) ModifyService(ctx context.Context, req *pb.ModifyServiceReq) (rsp *pb.ModifyServiceRsp, err error) {
	rsp = &pb.ModifyServiceRsp{Head: &basepb.RspHead{}}
	if rsp.Info, err = store.ModPodList(ctx, req.Platform, req.ServiceName, req.NodeName); err != nil {
		return
	}
	return
}
