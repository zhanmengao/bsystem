package service

import (
	"context"
	"fmt"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/base_proto/go/gerror"
	basepb "forevernine.com/midplat/base_proto/go/pb"
	"forevernine.com/midplat/base_server/transport/framework"
	"forevernine.com/midplat/scheduler/srv/master/internal/agent"
	"forevernine.com/midplat/scheduler/srv/master/internal/config"
	"forevernine.com/midplat/scheduler/srv/master/internal/store"
	"strings"
	"time"

	"forevernine.com/midplat/scheduler/proto/go/pb"
)

func (s *service) AgentLogin(ctx context.Context, req *pb.AgentLoginReq) (rsp *pb.AgentLoginRsp, err error) {
	rsp = &pb.AgentLoginRsp{Head: &basepb.RspHead{}}
	root := framework.GetBaseSpan(ctx)
	if root.IsValid() {
		root.AddAttr("node", req.NodeName)
		root.AddAttr("version", req.AgentVersion)
	}
	addr := framework.GetRemoteIP(ctx)
	if addr == "" {
		err = gerror.ErrServerNetwork().Format("not load remote ip ")
		return
	}
	//修改addr
	ips := strings.Split(addr, ":")
	if len(ips) < 2 {
		err = gerror.ErrServerNetwork().Format("ips error = %v ", ips)
		return
	}
	ports := strings.Split(req.GRPCAddr, ":")
	if len(ports) < 2 {
		err = gerror.ErrServerNetwork().Format("ips error = %v ", ports)
		return
	}
	addr = fmt.Sprintf("%s:%s", ips[0], ports[1])
	//构造能连的addr
	req.GRPCAddr = addr
	root.AddAttr("ip", addr)
	if rsp.Info, err = store.AgentLogin(ctx, req); err != nil {
		return
	}
	root.SetAttributes("platform", rsp.Info.Platform)
	//返回配置
	rsp.Config = config.BuildAgentConfig()

	//版本检测
	if req.AgentVersion != config.MasCfg.AgentVersion {
		go func() {
			time.Sleep(time.Duration(3) * time.Second)
			//发版本更新请求
			if err = agent.SendAgentUpdateReq(ctx, req.NodeName, config.MasCfg.AgentVersion); err != nil {
				xlog.Errorf(ctx, "update agent version error = %s ", err)
			}
		}()
	}
	return
}

func (s *service) AgentHeart(ctx context.Context, req *pb.AgentHeartBeatReq) (rsp *pb.AgentHeartBeatRsp, err error) {
	rsp = &pb.AgentHeartBeatRsp{Head: &basepb.RspHead{}}
	if err = store.UpdateAgentHeart(ctx, req.Info.NodeName); err != nil {
		return
	}
	return
}

func (s *service) AgentLogout(ctx context.Context, req *pb.AgentLogoutReq) (rsp *pb.AgentLogoutRsp, err error) {
	rsp = &pb.AgentLogoutRsp{Head: &basepb.RspHead{}}
	if err = store.AgentLogout(ctx, req); err != nil {
		return
	}
	return
}
