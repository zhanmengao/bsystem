package service

import (
	"context"
	"forevernine.com/midplat/base_server/transport/fgrpc"
	"forevernine.com/midplat/base_server/transport/fhttp"
	"forevernine.com/midplat/base_server/transport/framework"
	"forevernine.com/midplat/scheduler/proto/go/pb"
)

func Init(gSrv *fgrpc.Server, hSrv *fhttp.Server) (err error) {
	srv := &service{}
	gSrv.UsePreHandle(func(ctx context.Context, req framework.IProto) (context.Context, error) {
		if root := framework.GetBaseSpan(ctx); root.IsValid() {
			if pReq, ok := req.(platReq); ok {
				root.SetAttributes("platform", pReq.GetPlatform())
			}
		}
		return ctx, nil
	})
	pb.RegisterMasterServiceServer(gSrv, srv)
	pb.RegisterMasterAgentServer(gSrv, srv)
	pb.RegisterMasterManagerServer(gSrv, srv)
	return
}

type platReq interface {
	GetPlatform() string
}
