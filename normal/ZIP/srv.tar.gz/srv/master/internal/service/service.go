package service

import (
	"context"
	"forevernine.com/midplat/base_proto/go/gerror"
	basepb "forevernine.com/midplat/base_proto/go/pb"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/master/internal/agent"
	"forevernine.com/midplat/scheduler/srv/master/internal/store"
)

type service struct {
}

func (s *service) RunServer(ctx context.Context, req *pb.RunServerReq) (rsp *pb.RunServerRsp, err error) {
	rsp = &pb.RunServerRsp{Head: &basepb.RspHead{}}
	//拿到节点列表
	podList, err := store.GetPodList(ctx, req.Platform, req.ServiceName)
	if err != nil {
		return
	}
	if len(podList) <= 0 {
		err = gerror.ErrDataNotFound().Format("srv [%s] podlist not found", req.ServiceName)
		return
	}
	runPodList := make([]*pb.PodInfo, 0, len(podList))
	nodeList := make([]string, 0, len(podList))

	//此时只会有一个版本
	var version = podList[0].Version
	stopPodList := make([]uint64, 0, 10)
	//列出没有实例的pod
	for _, pod := range podList {
		var insList = pod.InstantList
		//大于一个ins，说明在部署流程中，不允许扩容
		if len(insList) > 1 {
			err = gerror.ErrServerBadParam().Format("srv %s in deploy now ", req.ServiceName)
			return
		}
		//将DELETE状态的移除
		if pod.Status == pb.POD_STATUS_DELETE {
			stopPodList = append(stopPodList, pod.PodID)
			nodeList = append(nodeList, pod.NodeName)
		} else if len(insList) <= 0 {
			//将小于等于一个实例的部署上去
			nodeList = append(nodeList, pod.NodeName)
			runPodList = append(runPodList, pod)
		}
	}
	//校验每个机器是否能够接收部署命令
	buildAgentList, err := agent.GetAndCheckAgent(ctx, req.Platform, nodeList)
	if err != nil {
		return
	}
	//遍历pod列表，开始部署
	for _, pod := range runPodList {
		for _, node := range buildAgentList {
			if node.NodeName == pod.NodeName {
				if err = agent.Deploy(ctx, req.Platform, pod.Version, req.ServiceName, pod.Command, pod.PodID, node, pb.INSTANT_STATUS_ENABLE, pod.HttpPort); err != nil {
					return
				}
			}
		}
	}
	if _, err = agent.SetInstantStatus(ctx, req.Platform, stopPodList, version, pb.INSTANT_STATUS_STOP); err != nil {
		return
	}
	if rsp.ServiceList, err = store.GetService(ctx, req.Platform, req.ServiceName); err != nil {
		return
	}
	return
}

func (s *service) GetServiceList(ctx context.Context, req *pb.GetServiceInfoReq) (rsp *pb.GetServiceInfoRsp, err error) {
	rsp = &pb.GetServiceInfoRsp{Head: &basepb.RspHead{}}
	m, err := store.GetAgentList(ctx, req.Platform)
	if err != nil {
		return
	}
	for _, n := range m {
		for _, srv := range n.ServiceList {
			if srv.ServiceName == req.ServiceName || req.ServiceName == "" {
				rsp.ServiceList = append(rsp.ServiceList, srv)
			}
		}
	}

	return
}
