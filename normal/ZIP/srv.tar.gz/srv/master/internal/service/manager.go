package service

import (
	"context"
	"forevernine.com/midplat/base_libs/xlog"
	basepb "forevernine.com/midplat/base_proto/go/pb"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/master/internal/agent"
	"forevernine.com/midplat/scheduler/srv/master/internal/store"
	"time"
)

func (s *service) ListAgent(ctx context.Context, req *pb.ListAgentReq) (rsp *pb.ListAgentRsp, err error) {
	rsp = &pb.ListAgentRsp{Head: &basepb.RspHead{}}
	rsp.Info, err = store.GetAgentList(ctx, req.Platform)
	return
}

func (s *service) AgentUpdate(ctx context.Context, req *pb.AgentUpdateReq) (rsp *pb.AgentUpdateRsp, err error) {
	rsp = &pb.AgentUpdateRsp{Head: &basepb.RspHead{}}
	//只更某个平台
	var nodeList []*pb.NodeInfo
	if req.Platform != "" {
		nodeList, err = store.GetAgentList(ctx, req.Platform)
	} else {
		nodeList, err = store.GetAllAgent(ctx)
	}
	if err != nil {
		return
	}
	for _, node := range nodeList {
		if err = agent.SendAgentUpdateReq(ctx, node.NodeName, req.Version); err != nil {
			xlog.Errorf(ctx, "send update to %s[%s] error = %s ", node.NodeName, node.GRPCAddr)
			err = nil
		}
	}
	return
}

func (s *service) AgentBind(ctx context.Context, req *pb.AgentBindReq) (rsp *pb.AgentBindRsp, err error) {
	rsp = &pb.AgentBindRsp{Head: &basepb.RspHead{}}
	rsp.Info, err = store.AgentBind(ctx, req)
	return
}

func (s *service) AgentDown(ctx context.Context, req *pb.AgentDownReq) (rsp *pb.AgentDownRsp, err error) {
	rsp = &pb.AgentDownRsp{Head: &basepb.RspHead{}}
	ret, err := store.AgentDown(ctx, req.NodeName)
	if err != nil {
		return
	}
	//call srv
	cli, err := pb.NewAgentFGrpcConn(ctx, ret.GRPCAddr, time.Duration(10)*time.Second)
	if err != nil {
		return
	}
	agRsp, err := cli.AgentDown(ctx, req, "")
	if err != nil {
		return
	}
	rsp.Info = agRsp.Info
	return
}
