package util

import (
	"github.com/sony/sonyflake"
	"time"
)

var (
	idGen = NewSonyFlake(0)
)

func NewSonyFlake(MachineID uint16) *sonyflake.Sonyflake {
	return sonyflake.NewSonyflake(sonyflake.Settings{
		StartTime: time.Date(2022, 1, 1, 0, 0, 0, 0, time.UTC),
		MachineID: func() (uint16, error) {
			return MachineID, nil
		},
		CheckMachineID: nil,
	})
}

func GenPodID() (podID uint64, err error) {
	podID, err = idGen.NextID()
	return
}
