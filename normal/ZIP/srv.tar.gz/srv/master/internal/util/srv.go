package util

import (
	"context"
	"fmt"
	"forevernine.com/midplat/base_proto/go/gerror"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"time"
)

func GetPlatformService(plat, srv string) string {
	return fmt.Sprintf("%s.%s", plat, srv)
}

func CheckAgent(ctx context.Context, addr string) (err error) {
	//尝试构造client，Ping不通则返回
	var cli pb.IAgentFGrpcConn
	if cli, err = pb.NewAgentFGrpcConn(ctx, addr, time.Second*time.Duration(3)); err != nil {
		err = gerror.ErrServerNetwork().Format("NodeName = [%s] .will stop create ", addr)
		return
	}
	if _, err = cli.Ping(ctx, &pb.PingReq{}, ""); err != nil {
		err = gerror.ErrServerNetwork().Format("NodeName = [%s] .will stop create ", addr)
		return
	}
	return
}
