package util

import "forevernine.com/midplat/scheduler/proto/go/pb"

type TNodeInfo struct {
	PidList []int64
	Info    *pb.NodeInfo
}
