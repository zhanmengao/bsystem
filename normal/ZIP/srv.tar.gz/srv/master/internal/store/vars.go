package store

import (
	"forevernine.com/midplat/base_server/mysqldb"
)

var (
	client mysqldb.IMySqlClient
)
