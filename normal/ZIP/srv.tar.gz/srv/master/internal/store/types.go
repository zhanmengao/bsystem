package store

import (
	"forevernine.com/midplat/scheduler/proto/go/pb"
)

type dbAgent struct {
	NodeName     string `gorm:"primaryKey"`
	Platform     string
	AgentVersion string
	AgentPid     int64
	GrpcAddr     string
	Status       pb.AGENT_STATUS
	LastHeart    int64
	CreatedAt    int64 `gorm:"autoCreateTime"`
	UpdatedAt    int64 `gorm:"autoUpdateTime"`
	DeletedAt    int64 `gorm:"autoDeleteTime"`
}

func (a *dbAgent) TableName() string {
	return "t_agent"
}
func (a *dbAgent) BuildProto() *pb.NodeInfo {
	return &pb.NodeInfo{
		Platform:     a.Platform,
		NodeName:     a.NodeName,
		GRPCAddr:     a.GrpcAddr,
		AgentPID:     a.AgentPid,
		AgentVersion: a.AgentVersion,
		ServiceList:  map[string]*pb.ServiceInfo{},
	}
}

//type dbService struct {
//	PlatformService string `gorm:"primaryKey"`
//	Platform        string
//	Service         string
//	CreatedAt       int64 `gorm:"autoCreateTime"`
//	UpdatedAt       int64 `gorm:"autoUpdateTime"`
//	DeletedAt       int64 `gorm:"autoDeleteTime"`
//}
//
//func (p *dbService) TableName() string {
//	return "t_service"
//}

type dbPod struct {
	PodId     uint64 `gorm:"primaryKey"`
	Platform  string
	NodeName  string
	Service   string
	Command   string
	Version   string
	Status    pb.POD_STATUS
	HttpPort  int64
	CreatedAt int64 `gorm:"autoCreateTime"`
	UpdatedAt int64 `gorm:"autoUpdateTime"`
	DeletedAt int64 `gorm:"autoDeleteTime"`
}

func newPod(platform, nodeName, srvName, version, command string, podId uint64, httpPort int64) *dbPod {
	p := &dbPod{
		Status: pb.POD_STATUS_CREATE,
	}
	p.PodId = podId
	p.Platform = platform
	p.Service = srvName
	p.NodeName = nodeName
	p.Version = version
	p.Command = command
	p.HttpPort = httpPort
	return p
}

func (p *dbPod) TableName() string {
	return "t_pod"
}
func (p *dbPod) BuildProto() *pb.PodInfo {
	return &pb.PodInfo{
		PodID:       p.PodId,
		NodeName:    p.NodeName,
		InstantList: []*pb.InstantInfo{},
		ServiceName: p.Service,
		Command:     p.Command,
		Version:     p.Version,
		Status:      p.Status,
		HttpPort:    p.HttpPort,
	}
}

func (p *dbPod) IsCustomHTTP() bool {
	return p.HttpPort > 0
}

type dbInstant struct {
	Id        int64  `gorm:"primaryKey"`
	Platform  string //联合索引
	Service   string //联合索引
	NodeName  string
	Pid       int64
	Status    pb.INSTANT_STATUS
	HttpPort  int64
	FrpcPort  int64
	GrpcPort  int64
	PodId     uint64
	Version   string
	Command   string
	CreatedAt int64 `gorm:"autoCreateTime"`
	UpdatedAt int64 `gorm:"autoUpdateTime"`
	DeletedAt int64 `gorm:"autoDeleteTime"`
}

func newDBIns(platform, nodeName, srvName string, info *pb.InstantInfo) *dbInstant {
	return &dbInstant{
		NodeName: nodeName,
		Platform: platform,
		Pid:      info.PID,
		FrpcPort: info.FRPCPort,
		GrpcPort: info.GRPCPort,
		PodId:    info.PodID,
		Service:  srvName,
		Version:  info.Version,
		HttpPort: info.HTTPPort,
		Status:   info.Status,
		Command:  info.Command,
	}
}

func (p *dbInstant) TableName() string {
	return "t_instant"
}
func (p *dbInstant) BuildProto() *pb.InstantInfo {
	return &pb.InstantInfo{
		PodID:    p.PodId,
		Status:   p.Status,
		Version:  p.Version,
		PID:      p.Pid,
		HTTPPort: p.HttpPort,
		FRPCPort: p.FrpcPort,
		GRPCPort: p.GrpcPort,
		Command:  p.Command,
		CreateAt: p.CreatedAt,
	}
}
