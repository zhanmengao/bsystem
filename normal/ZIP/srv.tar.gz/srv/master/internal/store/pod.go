package store

import (
	"context"
	"errors"
	"forevernine.com/midplat/base_proto/go/gerror"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/master/internal/util"
	"gorm.io/gorm"
)

// ModPodList 修改实例数量，只有表内已存在pod的情况才能用
func ModPodList(ctx context.Context, platform, srvName string, nodeList []string) (info *pb.ServiceInfo, err error) {
	err = client.Orm(ctx).Transaction(func(tx *gorm.DB) (err error) {
		//看service是否已存在
		dpl := make([]*dbPod, 0, 10)
		if err = tx.Where("platform = ? AND service = ? AND status != ? ", platform, srvName, pb.POD_STATUS_DELETE).Find(&dpl).Error; err != nil {
			if !errors.Is(err, gorm.ErrRecordNotFound) {
				err = gerror.ErrServerDatabase().SetBasicErr(err)
				return
			}
			err = nil
		}
		//取第0个，所有pod版本都是一致的
		if len(dpl) <= 0 {
			err = gerror.ErrServerBadParam().Format("You need to create service %s ", srvName)
			return
		}
		version := dpl[0].Version
		command := dpl[0].Command
		httpPort := dpl[0].HttpPort
		matchMap := make(map[uint64]*dbPod) //还未标记的pod
		for _, p := range dpl {
			matchMap[p.PodId] = p
		}
		addPodMap := make(map[uint64]string) //node列表上多出来的节点
		delPodList := make([]uint64, 0)      //node列表上少了的节点
		//将pod list和现有的pod最对比
		for _, nodeName := range nodeList {
			var bFound = false
			for _, p := range matchMap {
				//进行机器名匹配，然后删除成功匹配的节点
				if p.NodeName == nodeName {
					delete(matchMap, p.PodId)
					bFound = true
					break
				}
			}
			//新节点在现存列表找不到，是新增
			if !bFound {
				var podID uint64
				if podID, err = util.GenPodID(); err != nil {
					return
				}
				addPodMap[podID] = nodeName
			}
		}

		//match map中还存在未匹配的节点，是删除
		for _, p := range matchMap {
			delPodList = append(delPodList, p.PodId)
		}

		for podID, nodeName := range addPodMap {
			dp := newPod(platform, nodeName, srvName, version, command, podID, httpPort)
			if err = tx.Create(dp).Error; err != nil {
				err = gerror.ErrServerDatabase().SetBasicErr(err)
				return
			}
		}
		//将下线的pod标记为删除
		delPod := &dbPod{
			Status: pb.POD_STATUS_DELETE,
		}
		if err = tx.Where("pod_id IN ?", delPodList).Updates(delPod).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
			return
		}
		info, err = transGetService(tx, platform, srvName)
		return
	})
	if err != nil {
		return
	}
	return
}

func UpdatePodVersion(ctx context.Context, platform, version string, srvName ...string) (err error) {
	err = client.Orm(ctx).Transaction(func(tx *gorm.DB) (err error) {
		for _, srv := range srvName {
			//query instant
			insList := make([]*dbInstant, 0, 10)
			if err = tx.Where("platform = ? AND service = ? AND version = ? AND status = ?", platform, srv, version, pb.INSTANT_STATUS_ENABLE).Find(&insList).Error; err != nil {
				err = gerror.ErrServerDatabase().SetBasicErr(err)
				return
			}
			if len(insList) <= 0 {
				err = gerror.ErrServerInternalUnknown().Format("srv [%s] instant len = 0", srv)
				return
			}
			dp := &dbPod{
				Command: insList[0].Command,
				Version: version,
			}
			podidList := make([]uint64, 0, len(insList))
			for _, ins := range insList {
				podidList = append(podidList, ins.PodId)
			}
			if err = tx.Where("pod_id IN ?", podidList).Updates(dp).Error; err != nil {
				err = gerror.ErrServerDatabase().SetBasicErr(err)
				return
			}
		}
		return
	})
	return
}

func GetPodList(ctx context.Context, platform, srvName string) (pods []*pb.PodInfo, err error) {
	dbPodList := make([]*dbPod, 0, 10)
	if err = client.Orm(ctx).Where("platform = ? AND service = ? ", platform, srvName).Find(&dbPodList).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	//再读对应实例
	podIDList := make([]uint64, 0, len(dbPodList))
	pods = make([]*pb.PodInfo, 0, len(dbPodList))
	for _, pod := range dbPodList {
		podIDList = append(podIDList, pod.PodId)
		pods = append(pods, pod.BuildProto())
	}
	insList, err := GetInstantList(ctx, podIDList...)
	if err != nil {
		return
	}

	//将进程实例追加到pod
	for _, ins := range insList {
		for _, pod := range pods {
			if ins.PodID == pod.PodID {
				pod.InstantList = append(pod.InstantList, ins)
				break
			}
		}
	}
	return
}

func GetPod(ctx context.Context, podID ...uint64) (podInfo []*pb.PodInfo, err error) {
	err = client.Orm(ctx).Transaction(func(tx *gorm.DB) (err error) {
		podInfo, err = transGetPods(tx, podID...)
		return
	})
	return
}

func transGetPods(tx *gorm.DB, podID ...uint64) (podInfo []*pb.PodInfo, err error) {
	dpl := make([]*dbPod, 0, len(podID))
	if err = tx.Where("pod_id IN ? ", podID).Find(&dpl).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	for _, dp := range dpl {
		p := dp.BuildProto()
		p.InstantList, err = transGetInstantList(tx, dp.PodId)
		podInfo = append(podInfo, p)
	}

	return
}
