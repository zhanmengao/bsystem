package store

import (
	"context"
	"errors"
	"forevernine.com/midplat/base_libs/xtime"
	"forevernine.com/midplat/base_proto/go/gerror"
	basicConfig "forevernine.com/midplat/base_server/config"
	"forevernine.com/midplat/base_server/mysqldb"
	"gorm.io/gorm"

	"forevernine.com/midplat/scheduler/proto/go/pb"
)

const (
	DBNameMaster = "MasterDB"
)

func Init() (err error) {
	cfg, err := basicConfig.GetDBConfig(DBNameMaster)
	if err != nil {
		return
	}
	client, err = mysqldb.AddMysqlPool(DBNameMaster, cfg)
	return
}

// AgentBind 节点绑定
func AgentBind(ctx context.Context, req *pb.AgentBindReq) (ret *pb.NodeInfo, err error) {
	ag := &dbAgent{
		NodeName: req.NodeName,
		Platform: req.Platform,
		Status:   pb.AGENT_STATUS_INIT,
	}
	err = client.Orm(ctx).Transaction(func(tx *gorm.DB) (err error) {
		ret, err = transAgentBind(tx, req)
		return
	})
	ret = ag.BuildProto()
	return
}

func transAgentBind(tx *gorm.DB, req *pb.AgentBindReq) (ret *pb.NodeInfo, err error) {
	ag := &dbAgent{
		NodeName: req.NodeName,
		Platform: req.Platform,
		Status:   pb.AGENT_STATUS_OFFLINE,
	}
	//如果已经存在，则更新其状态
	if err = tx.Where("node_name = ?", req.NodeName).First(ag).Error; err != nil {
		//节点没有记录
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			err = gerror.ErrDataNotFound().Format("[%s] node not bind ", req.NodeName).SetBasicErr(err)
			return
		} else {
			if err = tx.Create(ag).Error; err != nil {
				err = gerror.ErrServerDatabase().SetBasicErr(err)
				return
			}
		}
	} else {
		if ag.Status != pb.AGENT_STATUS_DOWN {
			err = gerror.ErrServerBadParam().Format("node already online ")
			return
		}
		ag.Status = pb.AGENT_STATUS_OFFLINE
		//节点存在，并且找到了，更新数据
		if err = tx.Model(ag).Where("node_name = ? ", req.NodeName).Updates(ag).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
			return
		}
		//这个查询用于返回更新后的数据
		if err = tx.Where("node_name = ?", req.NodeName).First(ag).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
		}
	}
	ret = ag.BuildProto()

	return
}

// AgentLogin 节点登录
func AgentLogin(ctx context.Context, req *pb.AgentLoginReq) (ret *pb.NodeInfo, err error) {
	err = client.Orm(ctx).Transaction(func(tx *gorm.DB) (err error) {
		//尝试添加节点
		if _, err = transAgentLogin(tx, req); err != nil {
			return
		}
		//返回结果
		if ret, err = transGetAgentInfo(tx, req.NodeName, pb.AGENT_STATUS_ONLINE); err != nil {
			return
		}
		return
	})
	if err != nil {
		return
	}
	return
}

func transAgentLogin(tx *gorm.DB, req *pb.AgentLoginReq) (agent *dbAgent, err error) {
	agent = &dbAgent{}
	//如果已经存在，则更新其状态
	if err = tx.Where("node_name = ?", req.NodeName).First(agent).Error; err != nil {
		//节点没有记录，返回error
		if errors.Is(err, gorm.ErrRecordNotFound) {
			err = gerror.ErrDataNotFound().Format("[%s] node not bind ", req.NodeName).SetBasicErr(err)
			return
		} else {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
			return
		}
	} else {
		//如果当前状态是已经登录，返回error
		if agent.Status == pb.AGENT_STATUS_ONLINE {
			err = gerror.ErrServerBadParam().Format("node already online ")
			return
		}
		//节点已经下线，不允许登录
		if agent.Status == pb.AGENT_STATUS_DOWN {
			err = gerror.ErrServerBadParam().Format("node is offline")
			return
		}
		dbInfo := &dbAgent{
			NodeName:     req.NodeName,
			GrpcAddr:     req.GRPCAddr,
			AgentPid:     req.AgentPID,
			AgentVersion: req.AgentVersion,
			Status:       pb.AGENT_STATUS_ONLINE,
			LastHeart:    xtime.Unix(),
		}
		//节点存在，并且找到了，更新数据
		if err = tx.Model(dbInfo).Where("node_name = ? ", req.NodeName).Updates(dbInfo).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
			return
		}
		//这个查询用于返回更新后的数据
		if err = tx.Where("node_name = ?", req.NodeName).First(agent).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
		}
	}

	return
}

func AgentDown(ctx context.Context, nodeName string) (ret *pb.NodeInfo, err error) {
	err = client.Orm(ctx).Transaction(func(tx *gorm.DB) (err error) {
		ag := &dbAgent{
			Status: pb.AGENT_STATUS_DOWN,
		}
		if err = tx.Where("node_name = ?", nodeName).Updates(ag).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
			return
		}
		dpod := &dbPod{
			NodeName: nodeName,
			Status:   pb.POD_STATUS_DELETE,
		}
		if err = tx.Where("node_name = ?", nodeName).Updates(dpod).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
			return
		}
		if ret, err = transGetAgentInfo(tx, nodeName, pb.AGENT_STATUS_DOWN); err != nil {
			return
		}
		return
	})
	return
}

func GetAllAgent(ctx context.Context) (ret []*pb.NodeInfo, err error) {
	dbAgList := make([]*dbAgent, 0, 10)
	if err = client.Orm(ctx).Where("status = ?", pb.AGENT_STATUS_ONLINE).First(&dbAgList).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	for _, ag := range dbAgList {
		ret = append(ret, ag.BuildProto())
	}
	return
}
func GetAgentList(ctx context.Context, platform string) (ret []*pb.NodeInfo, err error) {
	err = client.Orm(ctx).Transaction(func(tx *gorm.DB) (err error) {
		ret, err = transGetAgentList(tx, platform)
		return
	})
	return
}

func transGetAgentList(tx *gorm.DB, platform string) (ret []*pb.NodeInfo, err error) {
	//读agent
	var nodeList = make([]*dbAgent, 0, 10)
	if err = tx.Where("platform = ? AND status = ?", platform, pb.AGENT_STATUS_ONLINE).Find(&nodeList).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	var podList = make([]*dbPod, 0, 10)
	if err = tx.Where("platform = ?", platform).Find(&podList).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	//读进程实例
	var instList = make([]*dbInstant, 0, 10)
	if err = tx.Where("platform = ? AND status != ?", platform, pb.INSTANT_STATUS_STOP).Find(&instList).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	ret, err = getAgentList(platform, nodeList, podList, instList)
	return
}

func GetAgentInfo(ctx context.Context, nodeName string) (ret *pb.NodeInfo, err error) {
	err = client.Orm(ctx).Transaction(func(tx *gorm.DB) (err error) {
		ret, err = transGetAgentInfo(tx, nodeName, pb.AGENT_STATUS_ONLINE)
		return
	})
	return
}

func transGetAgentInfo(tx *gorm.DB, nodeName string, status pb.AGENT_STATUS) (ret *pb.NodeInfo, err error) {
	var nodeList = make([]*dbAgent, 0, 1)
	if err = tx.Where("node_name = ? AND status = ?", nodeName, status).Find(&nodeList).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	if len(nodeList) <= 0 {
		err = gerror.ErrDataNotFound().Format(nodeName)
		return
	}
	platform := nodeList[0].Platform

	var podList = make([]*dbPod, 0, 10)
	if err = tx.Where("platform = ? AND node_name = ? ", platform, nodeName).Find(&podList).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}

	//读进程实例
	var instList = make([]*dbInstant, 0, 10)
	if err = tx.Where("node_name = ? AND status != ?", nodeName, pb.AGENT_STATUS_DOWN).Find(&instList).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	retList, err := getAgentList(platform, nodeList, podList, instList)
	if err != nil {
		return
	}
	if len(retList) < 1 {
		err = gerror.ErrDataNotFound().Format(platform).Format(nodeName)
		return
	}
	ret = retList[0]
	return
}

func AgentLogout(ctx context.Context, req *pb.AgentLogoutReq) (err error) {
	if err = client.Orm(ctx).Transaction(func(tx *gorm.DB) (err error) {
		dbInfo := &dbAgent{
			Status: pb.AGENT_STATUS_OFFLINE,
		}
		//节点存在，并且找到了，更新数据。根据PID来避免新旧进程修改状态异常
		if err = client.Orm(ctx).Model(dbInfo).Where("node_name = ? AND agent_pid = ? AND status = ?",
			req.Info.NodeName, req.Info.AgentPID, pb.AGENT_STATUS_ONLINE).Updates(dbInfo).Error; err != nil {
			err = gerror.ErrServerDatabase().Format(req.Info.NodeName).SetBasicErr(err)
			return
		}
		return
	}); err != nil {
		return
	}
	return
}

func UpdateAgentHeart(ctx context.Context, nodeName string) (err error) {
	ag := &dbAgent{
		NodeName:  nodeName,
		LastHeart: xtime.Unix(),
	}
	if err = client.Orm(ctx).Where("node_name = ?", nodeName).Updates(ag).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	return
}

func CheckAgentHeart(ctx context.Context) (err error) {
	agOff := &dbAgent{
		Status: pb.AGENT_STATUS_OFFLINE,
	}
	agOn := &dbAgent{
		Status: pb.AGENT_STATUS_ONLINE,
	}
	lastActive := xtime.Unix() - 30
	err = client.Orm(ctx).Transaction(func(tx *gorm.DB) (err error) {
		if err = tx.Where("last_heart < ? AND status = ? ", lastActive, pb.AGENT_STATUS_ONLINE).Updates(agOff).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
			return
		}
		if err = tx.Where("last_heart > ? AND status = ?", lastActive, pb.AGENT_STATUS_OFFLINE).Updates(agOn).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
			return
		}
		return
	})
	if err != nil {
	}

	return
}

func getAgentList(platform string, nodeList []*dbAgent, podList []*dbPod, instList []*dbInstant) (ret []*pb.NodeInfo, err error) {
	for _, n := range nodeList {
		ni := n.BuildProto()
		//先构造service和pod
		for _, p := range podList {
			if p.NodeName == n.NodeName {
				srv, ok := ni.ServiceList[p.Service]
				if !ok {
					srv = &pb.ServiceInfo{
						ServiceName: p.Service,
						PodList:     make(map[uint64]*pb.PodInfo),
					}
					ni.ServiceList[p.Service] = srv
				}
				srv.PodList[p.PodId] = p.BuildProto()
			}
		}
		//填充进程实例
		for _, i := range instList {
			if i.NodeName == ni.NodeName {
				//找到一个实例。这里如果出问题，应当panic，告出来是好事，早出现早解决
				ni.ServiceList[i.Service].PodList[i.PodId].InstantList =
					append(ni.ServiceList[i.Service].PodList[i.PodId].InstantList, i.BuildProto())
			}
		}
		ret = append(ret, ni)
	}
	return
}
