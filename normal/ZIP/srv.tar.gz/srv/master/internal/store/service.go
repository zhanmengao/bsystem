package store

import (
	"context"
	"forevernine.com/midplat/base_proto/go/gerror"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"gorm.io/gorm"
)

// CreateService 创建Service，增加pod实例
func CreateService(ctx context.Context, platform, srvName, version, command string, nodeList map[uint64]string, httpPort int64) (info *pb.ServiceInfo, err error) {
	err = client.Orm(ctx).Transaction(func(tx *gorm.DB) (err error) {
		//看service是否已存在，已存在则返回error
		var count int64 = 0
		dpCount := &dbPod{}
		if err = tx.Where("platform = ? AND service = ? AND status != ?", platform, srvName, pb.POD_STATUS_DELETE).Model(dpCount).Count(&count).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
			return
		}
		if count > 0 {
			err = gerror.ErrServerBadParam().Format("srv %s already exist", srvName)
			return
		}
		//在表中创建pod
		for podID, nodeName := range nodeList {
			dp := newPod(platform, nodeName, srvName, version, command, podID, httpPort)
			if err = tx.Create(dp).Error; err != nil {
				err = gerror.ErrServerDatabase().SetBasicErr(err)
				return
			}
		}
		info, err = transGetService(tx, platform, srvName)
		return
	})
	if err != nil {
		return
	}
	return
}

func GetService(ctx context.Context, platform, service string) (srvInfo *pb.ServiceInfo, err error) {
	if err = client.Orm(ctx).Transaction(func(tx *gorm.DB) (err error) {
		srvInfo, err = transGetService(tx, platform, service)
		return
	}); err != nil {
		return
	}
	return
}

func transGetService(tx *gorm.DB, platform, service string) (srvInfo *pb.ServiceInfo, err error) {
	srvInfo = &pb.ServiceInfo{
		ServiceName: service,
		PodList:     map[uint64]*pb.PodInfo{},
	}
	podList := make([]*dbPod, 0, 5)
	insList := make([]*dbInstant, 0, 10)
	if err = tx.Where("platform = ? AND service = ? ", platform, service).Find(&podList).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	//再读关联的进程
	if err = tx.Where("platform = ? AND service = ? AND status != ? ", platform, service, pb.AGENT_STATUS_DOWN).Find(&insList).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	for _, p := range podList {
		srvInfo.PodList[p.PodId] = p.BuildProto()
	}
	for _, v := range insList {
		srvInfo.PodList[v.PodId].InstantList = append(srvInfo.PodList[v.PodId].InstantList, v.BuildProto())
	}
	return
}
