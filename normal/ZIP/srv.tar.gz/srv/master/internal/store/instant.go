package store

import (
	"context"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/base_libs/xtime"
	"forevernine.com/midplat/base_proto/go/gerror"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"gorm.io/gorm"
)

// AddInstant 有新的实例被构建
func AddInstant(ctx context.Context, platform, nodeName, srvName string, ins *pb.InstantInfo) (err error) {
	dbIns := &dbInstant{
		NodeName: nodeName,
		Platform: platform,
		Status:   ins.Status,
		Version:  ins.Version,
		HttpPort: ins.HTTPPort,
		Pid:      ins.PID,
		FrpcPort: ins.FRPCPort,
		GrpcPort: ins.GRPCPort,
		PodId:    ins.PodID,
		Service:  srvName,
		Command:  ins.Command,
	}
	err = client.Orm(ctx).Transaction(func(tx *gorm.DB) (err error) {
		var count int64 = 0
		if err = tx.Where("node_name = ? AND pid = ?", nodeName, ins.PID).Table(dbIns.TableName()).Count(&count).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
			return
		}
		if count > 0 {
			err = gerror.ErrServerBadParam().Format("process %s already exists ", ins)
			return
		}
		if err = tx.Create(dbIns).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
			return
		}
		dp := &dbPod{}
		//先查状态，如果是DELETE则告警
		if err = tx.Where("pod_id = ?", ins.PodID).Find(dp).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
			return
		}
		if dp.Status == pb.POD_STATUS_DELETE {
			xlog.Warnf(ctx, "ins %s was created.but pod [%d] status is deleted ", ins, dp.PodId)
		}
		//修改状态为running
		dbUpdate := &dbPod{
			Status: pb.POD_STATUS_RUNNING,
		}
		if err = tx.Where("pod_id = ? AND status = ? ", ins.PodID, pb.POD_STATUS_CREATE).Updates(dbUpdate).Error; err != nil {
			err = gerror.ErrServerDatabase().SetBasicErr(err)
			return
		}
		return
	})
	if err != nil {
		return
	}

	return
}

// UpdateInstantStatus 更新进程信息
func UpdateInstantStatus(ctx context.Context, platform, nodeName string, status pb.INSTANT_STATUS, pid []int64) (err error) {
	dbIns := &dbInstant{
		NodeName: nodeName,
		Platform: platform,
		Status:   status,
	}
	if err = client.Orm(ctx).Where("node_name = ? AND platform = ? AND pid IN ?", nodeName, platform, pid).Updates(dbIns).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	return
}

func GetInstantList(ctx context.Context, podID ...uint64) (instantList []*pb.InstantInfo, err error) {
	instantList, err = transGetInstantList(client.Orm(ctx), podID...)
	return
}

func transGetInstantList(tx *gorm.DB, podID ...uint64) (instantList []*pb.InstantInfo, err error) {
	insList := make([]*dbInstant, 0, 5)
	if err = tx.Where("pod_id IN ? AND status != ? ", podID, pb.INSTANT_STATUS_STOP).Find(&insList).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	for _, ins := range insList {
		instantList = append(instantList, ins.BuildProto())
	}
	return
}

func ClearStopInstant(ctx context.Context) (err error) {
	dbInsList := make([]*dbInstant, 0, 10)
	delTm := xtime.Unix() - 24*60*60
	if err = client.Orm(ctx).Where("status = ? AND updated_at < ?", pb.INSTANT_STATUS_STOP, delTm).Delete(dbInsList).Error; err != nil {
		err = gerror.ErrServerDatabase().SetBasicErr(err)
		return
	}
	return
}
