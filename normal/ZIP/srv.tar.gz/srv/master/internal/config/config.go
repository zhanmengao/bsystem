package config

import (
	"context"
	"forevernine.com/midplat/base_libs/icfg/cfgtp"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/base_libs/xlog/logtyp"
	basicConfig "forevernine.com/midplat/base_server/config"
	"forevernine.com/midplat/base_server/ftrace"
	"forevernine.com/midplat/scheduler/common/def"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/master/internal/agent"
	"os"
)

type MasterConfig struct {
	Net                cfgtp.ListenConfig
	MasterAddr         string `yaml:"master_addr"`
	RunImmediately     bool   `yaml:"run_immediately"`
	DaemonMs           int    `yaml:"daemon_ms"`
	DialFailCount      int    `yaml:"dial_fail_count"`
	FirstDialSec       int    `yaml:"first_dial_sec"`
	AgentVersion       string `yaml:"agent_version"`
	StdioRedirect      bool   `yaml:"stdio_redirect"`
	MasterHeartTickSec int    `yaml:"master_heart_tick_sec"`
	MasterClearTickSec int    `yaml:"master_clear_tick_sec"`
	ServerDownloadURL  string `yaml:"server_download_url"`
}

func (s *MasterConfig) GetNet() cfgtp.ListenConfig {
	return s.Net
}

var BasCfg cfgtp.BasicConfig
var MasCfg = MasterConfig{
	MasterHeartTickSec: 5,
	MasterClearTickSec: 300,
}

func loadBaseConfig(ctx context.Context, srvName string, srvCfg cfgtp.IServerConfig) (err error) {
	if err = basicConfig.LoadDefaultConfig(ctx, def.ConfigFile, &BasCfg, srvName, srvCfg, def.ProtoPkgName); err != nil {
		return
	}
	return
}

func InitReply(ctx context.Context) (err error) {
	if err = loadBaseConfig(ctx, def.ServerNameMaster, &MasCfg); err != nil {
		return
	}
	if err = basicConfig.GetBaseMonitor().GetAndWatch("basecfg", &BasCfg, onBasicConfigChanged); err != nil {
		return
	}
	if err = basicConfig.GetBaseMonitor().GetAndWatch("master", &MasCfg, onMasterConfigChanged); err != nil {
		return
	}
	if def.RedirectIO {
		iopf, err := os.OpenFile(def.GetMonitPath(def.ServerNameMaster), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
		if err != nil {
			xlog.Errorf(context.Background(), "re stdio error = %s ", err)
			return err
		}
		os.Stdout = iopf
		os.Stderr = iopf
		if err = xlog.UseF9Log(BasCfg.LogPath, def.ServerNameMaster, def.ServerNameMaster, BasCfg.LogLevel); err != nil {
			return err
		}
	}
	return
}

func onBasicConfigChanged(key string, oldConfig interface{}, newConfig interface{}) {
	BasCfg = *newConfig.(*cfgtp.BasicConfig)
	ctx, span := ftrace.NewSpan(context.Background(), "basic_cfg", "changed")
	defer span.End()
	xlog.SetLogLevel(logtyp.ParseLevel(BasCfg.LogLevel))

	err := onConfigChanged(ctx)
	if err != nil {
		span.SetError(err)
	}
}

func onMasterConfigChanged(key string, oldConfig interface{}, newConfig interface{}) {
	MasCfg = *newConfig.(*MasterConfig)
	ctx, span := ftrace.NewSpan(context.Background(), "master_cfg", "changed")
	defer span.End()
	err := onConfigChanged(ctx)
	if err != nil {
		span.SetError(err)
	}
}

func onConfigChanged(ctx context.Context) (err error) {
	err = agent.SendConfigUpdateReq(ctx, BuildAgentConfig())
	return
}

func BuildAgentConfig() *pb.AgentConfig {
	return &pb.AgentConfig{
		PushAddr:          BasCfg.PushGateway,
		FirstDialSec:      int64(MasCfg.FirstDialSec),
		DaemonMs:          int64(MasCfg.DaemonMs),
		DialFailCount:     int64(MasCfg.DialFailCount),
		TraceAddr:         BasCfg.TracerAddr,
		Env:               BasCfg.Env,
		LogLevel:          BasCfg.LogLevel,
		ServerDownloadURL: MasCfg.ServerDownloadURL,
	}
}

func GetOpenStatus() pb.INSTANT_STATUS {
	switch MasCfg.RunImmediately {
	case true:
		return pb.INSTANT_STATUS_ENABLE
	case false:
		return pb.INSTANT_STATUS_DISABLE
	}
	return pb.INSTANT_STATUS_DISABLE
}
