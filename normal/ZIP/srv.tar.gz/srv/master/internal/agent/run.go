package agent

import (
	"context"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/scheduler/srv/master/internal/store"
	"time"
)

func Run(heart, clear *int) {
	heartTm := time.NewTimer(time.Duration(*heart) * time.Second)
	clearTm := time.NewTimer(time.Duration(*clear) * time.Second)
	if err := store.CheckAgentHeart(context.Background()); err != nil {
		xlog.Fatalf(context.Background(), "check agent heart error = %s ", err)
	}
	for {
		ctx := context.Background()
		select {
		case <-heartTm.C:
			//扫描30秒未心跳的节点，设置为离线
			if err := store.CheckAgentHeart(ctx); err != nil {
				xlog.Fatalf(ctx, "check agent heart error = %s ", err)
			}
			heartTm.Reset(time.Duration(*heart) * time.Second)
		case <-clearTm.C:
			if err := store.ClearStopInstant(ctx); err != nil {
				xlog.Errorf(ctx, "clear old instant error = %s ", err)
			}
			clearTm.Reset(time.Duration(*clear) * time.Second)
		}

	}
}
