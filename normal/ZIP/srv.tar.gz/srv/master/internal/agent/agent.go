package agent

import (
	"context"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/master/internal/store"
	"time"
)

func SendAgentUpdateReq(ctx context.Context, nodeName, version string) (err error) {
	agent, err := store.GetAgentInfo(ctx, nodeName)
	if err != nil {
		return
	}
	cli, err := pb.NewAgentFGrpcConn(ctx, agent.GRPCAddr, time.Duration(10)*time.Second)
	if err != nil {
		return
	}
	_, err = cli.AgentUpdate(ctx, &pb.AgentUpdateReq{
		Platform: agent.Platform,
		Version:  version,
	}, "")
	if err != nil {
		return
	}
	return
}

func SendConfigUpdateReq(ctx context.Context, cfg *pb.AgentConfig) (err error) {
	//获取所有在线的节点
	agList, err := store.GetAllAgent(ctx)
	if err != nil {
		return
	}
	req := &pb.ConfigChangedReq{
		Config: cfg,
	}
	for _, ag := range agList {
		func() {
			defer func() {
				if err != nil {
					xlog.Errorf(ctx, "send config to [%s]:[%s] error = %s", ag.NodeName, ag.GRPCAddr, err)
				}
			}()
			cli, err := pb.NewAgentFGrpcConn(ctx, ag.GRPCAddr, time.Duration(5)*time.Second)
			if err != nil {
				return
			}
			_, err = cli.ConfigUpdate(ctx, req, "")
			if err != nil {
				return
			}
		}()
	}
	return
}
