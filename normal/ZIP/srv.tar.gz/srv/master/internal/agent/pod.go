package agent

import (
	"context"
	"forevernine.com/midplat/base_proto/go/gerror"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/master/internal/store"
	"forevernine.com/midplat/scheduler/srv/master/internal/util"
	"time"
)

// SetInstantStatus 设置实例状态
func SetInstantStatus(ctx context.Context, platform string, podList []uint64, version string, status pb.INSTANT_STATUS) (info []*pb.PodInfo, err error) {
	disableList := make(map[string]*util.TNodeInfo)
	stopList := make(map[string]*util.TNodeInfo)
	enableList := make(map[string]*util.TNodeInfo)
	for _, podID := range podList {
		//根据Pod获取instant
		var pil []*pb.PodInfo
		if pil, err = store.GetPod(ctx, podID); err != nil {
			return
		}
		var podInfo = pil[0]
		//获取node
		var nodeInfo *pb.NodeInfo
		if nodeInfo, err = store.GetAgentInfo(ctx, podInfo.NodeName); err != nil {
			return
		}
		//如果是STOP，则是节点下线
		if status == pb.INSTANT_STATUS_STOP {
			if _, exist := stopList[nodeInfo.GRPCAddr]; !exist {
				stopList[nodeInfo.GRPCAddr] = &util.TNodeInfo{
					PidList: make([]int64, 0, 10),
					Info:    nodeInfo,
				}
			}
			//找PID
			pidList := make([]int64, 0, 10)
			for _, ins := range podInfo.InstantList {
				if ins.Version == version {
					pidList = append(pidList, ins.PID)
				}
			}
			stopList[nodeInfo.GRPCAddr].PidList = append(stopList[nodeInfo.GRPCAddr].PidList, pidList...)
		} else if status == pb.INSTANT_STATUS_ENABLE {
			//变更服务状态，常见于灰度
			addInstant2Map(enableList, disableList, nodeInfo, pb.INSTANT_STATUS_ENABLE, version, podInfo.InstantList)
		} else if status == pb.INSTANT_STATUS_DISABLE {
			addInstant2Map(disableList, enableList, nodeInfo, pb.INSTANT_STATUS_DISABLE, version, podInfo.InstantList)
		}
	}
	//先探测。Enable和Dis一定是一对，只探测一个map即可
	for addr, _ := range enableList {
		if err = util.CheckAgent(ctx, addr); err != nil {
			return
		}
	}
	for addr, _ := range stopList {
		if err = util.CheckAgent(ctx, addr); err != nil {
			return
		}
	}
	//开始修改状态
	for addr, nodeInfo := range enableList {
		if err = setInstantStatus(ctx, platform, nodeInfo.Info.NodeName, addr, nodeInfo.PidList, pb.INSTANT_STATUS_ENABLE); err != nil {
			return
		}
	}
	for addr, nodeInfo := range disableList {
		if err = setInstantStatus(ctx, platform, nodeInfo.Info.NodeName, addr, nodeInfo.PidList, pb.INSTANT_STATUS_DISABLE); err != nil {
			return
		}
	}
	for addr, nodeInfo := range stopList {
		if err = setInstantStatus(ctx, platform, nodeInfo.Info.NodeName, addr, nodeInfo.PidList, pb.INSTANT_STATUS_STOP); err != nil {
			return
		}
	}
	info, err = store.GetPod(ctx, podList...)

	return
}

// SetVersionEnable 全面启动某个版本
func SetVersionEnable(ctx context.Context, platform string, ServiceName []string, version string) (err error) {
	//获取相关Service
	stopList := make(map[string]*util.TNodeInfo)
	enableList := make(map[string]*util.TNodeInfo)
	for _, srvName := range ServiceName {
		var srvInfo *pb.ServiceInfo
		if srvInfo, err = store.GetService(ctx, platform, srvName); err != nil {
			return
		}
		for _, pod := range srvInfo.PodList {
			if pod.Status != pb.POD_STATUS_RUNNING {
				continue
			}
			for _, ins := range pod.InstantList {
				var nodeInfo *pb.NodeInfo
				if nodeInfo, err = store.GetAgentInfo(ctx, pod.NodeName); err != nil {
					return
				}
				//把没enable的节点设置Enable
				if ins.Version == version && ins.Status != pb.INSTANT_STATUS_ENABLE {
					if _, exist := enableList[nodeInfo.GRPCAddr]; !exist {
						enableList[nodeInfo.GRPCAddr] = &util.TNodeInfo{
							PidList: make([]int64, 0, 10),
							Info:    nodeInfo,
						}
					}
					enableList[nodeInfo.GRPCAddr].PidList = append(enableList[nodeInfo.GRPCAddr].PidList, ins.PID)
				}
				//把没stop的节点设置Stop
				if ins.Version != version && ins.Status != pb.INSTANT_STATUS_STOP {
					if _, exist := stopList[nodeInfo.GRPCAddr]; !exist {
						stopList[nodeInfo.GRPCAddr] = &util.TNodeInfo{
							PidList: make([]int64, 0, 10),
							Info:    nodeInfo,
						}
					}
					stopList[nodeInfo.GRPCAddr].PidList = append(stopList[nodeInfo.GRPCAddr].PidList, ins.PID)
				}
			}
		}
	}
	//先探测
	for addr, _ := range enableList {
		if err = util.CheckAgent(ctx, addr); err != nil {
			return
		}
	}
	for addr, _ := range stopList {
		if err = util.CheckAgent(ctx, addr); err != nil {
			return
		}
	}

	//开始修改状态
	for addr, nodeInfo := range enableList {
		if err = setInstantStatus(ctx, platform, nodeInfo.Info.NodeName, addr, nodeInfo.PidList, pb.INSTANT_STATUS_ENABLE); err != nil {
			return
		}
	}
	for addr, nodeInfo := range stopList {
		if err = setInstantStatus(ctx, platform, nodeInfo.Info.NodeName, addr, nodeInfo.PidList, pb.INSTANT_STATUS_STOP); err != nil {
			return
		}
	}
	return
}

func addInstant2Map(sameMap, differentMap map[string]*util.TNodeInfo, nodeInfo *pb.NodeInfo, status pb.INSTANT_STATUS, version string, instList []*pb.InstantInfo) {
	//变更服务状态，常见于灰度
	if _, exist := sameMap[nodeInfo.GRPCAddr]; !exist {
		sameMap[nodeInfo.GRPCAddr] = &util.TNodeInfo{
			PidList: make([]int64, 0, 10),
			Info:    nodeInfo,
		}
	}
	//变更服务状态，常见于灰度
	if _, exist := differentMap[nodeInfo.GRPCAddr]; !exist {
		differentMap[nodeInfo.GRPCAddr] = &util.TNodeInfo{
			PidList: make([]int64, 0, 10),
			Info:    nodeInfo,
		}
	}
	//找PID
	samePidList := make([]int64, 0, 10)
	diffPidList := make([]int64, 0, 10)
	for _, ins := range instList {
		//一个被enable，另一个就要被disable
		if ins.Version == version && ins.Status != status {
			samePidList = append(samePidList, ins.PID)
		} else if ins.Version != version && ins.Status == status {
			diffPidList = append(diffPidList, ins.PID)
		}
	}
	sameMap[nodeInfo.GRPCAddr].PidList = append(sameMap[nodeInfo.GRPCAddr].PidList, samePidList...)
	differentMap[nodeInfo.GRPCAddr].PidList = append(differentMap[nodeInfo.GRPCAddr].PidList, diffPidList...)
}

func setInstantStatus(ctx context.Context, platform, nodeName, nodeAddr string, pid []int64, status pb.INSTANT_STATUS) (err error) {
	if len(pid) <= 0 {
		return
	}
	cli, err := pb.NewAgentFGrpcConn(ctx, nodeAddr, time.Duration(10)*time.Second)
	if err != nil {
		return
	}
	rsp, err := cli.SetInstantStatus(ctx, &pb.SetInstantStatusReq{
		Status: status,
		Pid:    pid,
	}, "")
	if err != nil {
		return
	}
	//更新DB
	if len(rsp.InstantList) != len(pid) {
		err = gerror.ErrServerInternalUnknown().Format("rsp status len error %d .%d .", len(rsp.InstantList), len(pid))
		return
	}
	if err = store.UpdateInstantStatus(ctx, platform, nodeName, status, pid); err != nil {
		return
	}
	return
}
