package agent

import (
	"context"
	"forevernine.com/midplat/base_proto/go/gerror"
	"forevernine.com/midplat/scheduler/proto/go/pb"
	"forevernine.com/midplat/scheduler/srv/master/internal/store"
	"forevernine.com/midplat/scheduler/srv/master/internal/util"
	"time"
)

func GetAndCheckAgent(ctx context.Context, platform string, nodeList []string) (buildAgentList []*pb.NodeInfo, err error) {
	//获取Agent列表
	al, err := store.GetAgentList(ctx, platform)
	if err != nil {
		return
	}
	buildAgentList = make([]*pb.NodeInfo, 0, len(nodeList))
	for _, n := range nodeList {
		//找到对应的机器信息
		bFound := false
		for _, a := range al {
			if a.NodeName == n {
				if err = util.CheckAgent(ctx, a.GRPCAddr); err != nil {
					return
				}
				//尝试端口号决策
				//if _, _, _, err = GetPort(minPort, maxPort, a); err != nil {
				//	//无法决策，无空余端口号，返回
				//	return
				//}
				buildAgentList = append(buildAgentList, a)
				bFound = true
				break
			}
		}
		if !bFound {
			//到这里，说明有机器找不到
			err = gerror.ErrDataNotFound().Format("NodeName = [%s] .will stop create ", n)
			return
		}
		return
	}
	return
}

func Deploy(ctx context.Context, platform, version, srvName, command string, podID uint64, ag *pb.NodeInfo, status pb.INSTANT_STATUS, httpPort int64) (err error) {
	var cli pb.IAgentFGrpcConn
	if cli, err = pb.NewAgentFGrpcConn(ctx, ag.GRPCAddr, time.Second*time.Duration(3)); err != nil {
		err = gerror.ErrServerNetwork().Format("NodeName = [%s] .will stop create ", ag.NodeName)
		return
	}
	//var frpcPort, grpcPort, httpPort int64
	//frpcPort, grpcPort, httpPort, err = GetPort(minPort, maxPort, ag)
	//if err != nil {
	//	//无法决策，无空余端口号，返回
	//	return
	//}
	//请求agent创建服务
	var insReq *pb.CreateInstantRsp
	insReq, err = cli.CreateInstant(ctx, &pb.CreateInstantReq{
		//FRPCPort: frpcPort,
		//GRPCPort: grpcPort,
		//HTTPPort: httpPort,
		Version:  version,
		Service:  srvName,
		Command:  command,
		PodID:    podID,
		Status:   status,
		HttpPort: httpPort,
	}, "")
	if err != nil {
		return
	}
	//记录创建结果
	if err = store.AddInstant(ctx, platform, ag.NodeName, srvName, &pb.InstantInfo{
		Status:   insReq.Info.Status,
		HTTPPort: insReq.Info.HTTPPort,
		FRPCPort: insReq.Info.FRPCPort,
		GRPCPort: insReq.Info.GRPCPort,
		PID:      insReq.Info.PID,
		Version:  version,
		PodID:    podID,
		Command:  command,
	}); err != nil {
		return
	}
	return
}

// GetPort 端口号决策
//func GetPort(min, max int64, nodeInfo *pb.NodeInfo) (frpcPort int64, grpcPort int64, httpPort int64, err error) {
//	if min <= 1024 {
//		err = gerror.ErrServerBadParam().Format("min = %d .max = %d .Do not use ports below 1024")
//		return
//	}
//	if max-min < 100 {
//		err = gerror.ErrServerBadParam().Format("min = %d .max = %d .The maximum value must exceed the minimum value of 100")
//		return
//	}
//	//先判断配置端口号是否有冲突
//	var podInfo *pb.PodInfo
//	for _, srv := range nodeInfo.ServiceList {
//		//传入的最小值大于已有的最大值，不可能交集
//		if srv.MaxPort < min {
//			continue
//		}
//		//传入的最大值小于已有最小值，不可能交集
//		if srv.MinPort > max {
//			continue
//		}
//		err = gerror.ErrServerBadParam().Format("node [%s] min=%d .max = %d ."+
//			"but input min = %d ,max = %d .not allow", srv.ServiceName, srv.MinPort, srv.MaxPort, min, max)
//		return
//	}
//	alReadyUse := make(map[int64]struct{})
//	//找一下当前pod使用的端口
//	if podInfo != nil {
//		//直接找到当前的最大端口，然后在它的基础上自增
//		maxPort := min
//		for _, ins := range podInfo.InstantList {
//			alReadyUse[ins.HTTPPort] = struct{}{}
//			alReadyUse[ins.GRPCPort] = struct{}{}
//			alReadyUse[ins.FRPCPort] = struct{}{}
//			if ins.FRPCPort > maxPort {
//				maxPort = ins.FRPCPort + 3
//			}
//		}
//		//处理一下轮回的情况
//		frpcPort = (maxPort % min) + min
//	} else {
//		frpcPort = min
//	}
//	//处理一下轮回的情况
//	grpcPort = (frpcPort+1)%min + min
//	httpPort = (grpcPort+1)%min + min
//	if _, exist := alReadyUse[frpcPort]; exist {
//		err = gerror.ErrServerBadParam().Format("not free port in %s .min = [%d] max = [%d]", nodeInfo.NodeName, min, max)
//		return
//	}
//	if _, exist := alReadyUse[grpcPort]; exist {
//		err = gerror.ErrServerBadParam().Format("not free port in %s .min = [%d] max = [%d]", nodeInfo.NodeName, min, max)
//		return
//	}
//	if _, exist := alReadyUse[httpPort]; exist {
//		err = gerror.ErrServerBadParam().Format("not free port in %s .min = [%d] max = [%d]", nodeInfo.NodeName, min, max)
//		return
//	}
//	return
//}
