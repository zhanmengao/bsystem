package master

import (
	"context"
	"forevernine.com/midplat/base_libs/prom"
	"forevernine.com/midplat/base_libs/xlog"
	"forevernine.com/midplat/base_server/ftrace"
	"forevernine.com/midplat/base_server/transport/fgrpc"
	"forevernine.com/midplat/base_server/transport/fhttp"
	"forevernine.com/midplat/base_server/transport/framework"
	"forevernine.com/midplat/scheduler/common/def"
	"forevernine.com/midplat/scheduler/srv/master/internal/agent"
	"forevernine.com/midplat/scheduler/srv/master/internal/config"
	"forevernine.com/midplat/scheduler/srv/master/internal/service"
	"forevernine.com/midplat/scheduler/srv/master/internal/store"
	"math/rand"
	"strings"
)

func Run() (err error) {
	def.FlagParse()
	ctx := context.Background()
	if err = config.InitReply(ctx); err != nil {
		panic(err)
	}

	if err = store.Init(); err != nil {
		panic(err)
	}

	ss := strings.Split(config.BasCfg.GetPlatform(), "_")
	framework.InitRPCProm(ss[0], def.ServerNameMaster)
	ftrace.StartTracer(config.BasCfg.GetPlatform(), def.ServerNameMaster, config.BasCfg.GetTracerAddr(), def.Version)

	prom.InitPush(ctx, config.BasCfg.PushGateway, def.InstanceName(config.MasCfg.Net.HTTPPort), def.ServerNameMaster, config.BasCfg.Platform)

	gsrv := fgrpc.NewServer(def.ServerNameMaster, &config.BasCfg, &config.MasCfg.Net).UseTracer(func(ctx context.Context, method, uid string) bool {
		if method == "AgentHeart" || method == "InstantDump" || method == "InstantRestart" {
			return rand.Int63n(1000) <= 10
		}
		return true
	})

	hsrv := fhttp.NewServer(def.ServerNameMaster, &config.BasCfg, &config.MasCfg.Net)

	if err = service.Init(gsrv, hsrv); err != nil {
		panic(err)
	}

	go agent.Run(&config.MasCfg.MasterHeartTickSec, &config.MasCfg.MasterClearTickSec)

	//grpc server不去初始化服务发现，只使用中间件
	xlog.Infof(ctx, "[gRPC] server listening on: %s", gsrv.GetLis().Addr().String())
	go func() {
		if err = gsrv.Serve(gsrv.GetLis()); err != nil {
			panic(err)
		}
	}()

	if err = hsrv.Start(ctx); err != nil {
		panic(err)
	}

	select {}
}
